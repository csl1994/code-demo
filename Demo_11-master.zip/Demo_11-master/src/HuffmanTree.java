import java.util.ArrayList;
import java.util.List;

public class HuffmanTree{

	private HuffmanTreeNode root = new HuffmanTreeNode();

	private class HuffmanTreeNode{

		private String data;
		private int weight;
		private HuffmanTreeNode leftChild;
		private HuffmanTreeNode rightChild;

		public HuffmanTreeNode(){
			data = "";
			weight = 0;
			leftChild = null;
			rightChild = null;
		}

		public HuffmanTreeNode(String data, int weight){
			this.data = data;
			this.weight = weight;
			leftChild = null;
			rightChild = null;
		}

		public void visit(){
			System.out.println(data + ":" + weight);
		}
	}

	private HuffmanTreeNode buildTree(List<HuffmanTreeNode> nodes){
		
		nodes.add(new HuffmanTreeNode("A" , 40));  
	    nodes.add(new HuffmanTreeNode("B" , 8));  
	    nodes.add(new HuffmanTreeNode("C" , 10));  
	    nodes.add(new HuffmanTreeNode("D" , 30));  
	    nodes.add(new HuffmanTreeNode("E" , 10));  
	    nodes.add(new HuffmanTreeNode("F" , 2)); 

		while(nodes.size() > 1){
			quickSort(nodes, 0, nodes.size() - 1);
			HuffmanTreeNode leftChild = nodes.get(nodes.size() - 1);
			HuffmanTreeNode rightChild = nodes.get(nodes.size() - 2);
			HuffmanTreeNode parent = new HuffmanTreeNode(null, leftChild.weight + rightChild.weight);
			parent.leftChild = leftChild;
			parent.rightChild = rightChild;

			nodes.remove(nodes.size() - 1);
			nodes.remove(nodes.size() - 1);
			nodes.add(parent);
		}
		return nodes.get(0);
	}

	private void swap(List<HuffmanTreeNode> nodes, int i, int j){
		HuffmanTreeNode tmp = nodes.get(i);
		nodes.set(i,nodes.get(j));
		nodes.set(j,tmp);
	}

	public int partition(List<HuffmanTreeNode> nodes, int low, int high){
		HuffmanTreeNode privotKey = nodes.get(low);
		while(low < high){
			while(low < high && nodes.get(high).weight <= privotKey.weight){
				high --;
			}
			swap(nodes, low, high);
			
			while(low < high && nodes.get(low).weight >= privotKey.weight){
				low ++;
			}
			swap(nodes, low, high);
		}
//		show(nodes);
		return low;
	}

	private void quickSort(List<HuffmanTreeNode> nodes, int low, int high){
		if(low < high){
			int privotLoc = partition(nodes, low, high);
			quickSort(nodes, low, privotLoc - 1);
			quickSort(nodes, privotLoc + 1, high);
		}
	}

//	public void show(List<HuffmanTreeNode> nodes){
//		for(int i = 0; i < nodes.size(); i ++){
//			nodes.get(i).visit();
//		}
//		System.out.println("");
//	}
	
	public void preOrder(HuffmanTreeNode n){
    	if(n != null){
    		n.visit();
    		preOrder(n.leftChild);
    		preOrder(n.rightChild);
    	}
    }

    public static void main(String[] args)  
    {  
        List<HuffmanTreeNode> nodes = new ArrayList<HuffmanTreeNode>();  
        
        HuffmanTree ht = new HuffmanTree();
        ht.root = ht.buildTree(nodes);

		ht.preOrder(ht.root);
		System.out.println("end");  
    } 
}




