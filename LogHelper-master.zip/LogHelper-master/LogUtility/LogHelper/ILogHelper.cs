﻿namespace LogUtility.LogHelper
{
    #region using directives

    using System;

    #endregion using directives

    public interface ILogHelper
    {
        void InitLogHelper(String logFilePath);

        void WriteLog(String logText, LogType logType);

        void WriteLog(Exception exception);

        void Dispose();
    }

    public enum LogType
    {
        INFO,
        WARNING,
        ERROR
    }
}