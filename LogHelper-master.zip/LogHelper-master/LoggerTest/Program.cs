﻿namespace LoggerTest
{
    #region using directives

    using LogUtility.LogHelper;
    using System;
    using System.Threading;

    #endregion using directives

    internal class Program
    {
        private static readonly ILogHelper logger = LogHelper.GetLogHelper();

        public static void Main()
        {
            logger.InitLogHelper(@"D:\logger.log");
            var thread1 = new Thread(() =>
            {
                var num = 50;
                while (num-- > 0)
                {
                    logger.WriteLog("thread1" + num, LogType.INFO);
                    Thread.Sleep(new Random().Next(100, 500));
                }
            });
            var thread2 = new Thread(() =>
            {
                var num = 50;
                while (num-- > 0)
                {
                    logger.WriteLog("thread2" + num, LogType.WARNING);
                    Thread.Sleep(new Random().Next(400, 500));
                }
            });
            var thread3 = new Thread(() =>
            {
                var num = 50;
                while (num-- > 0)
                {
                    logger.WriteLog(new Exception("thread3" + num));
                    Thread.Sleep(new Random().Next(100, 300));
                }
            });
            try
            {
                thread1.Start();
                thread2.Start();
                thread3.Start();
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception.ToString());
            }
        }
    }
}