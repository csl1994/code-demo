import java.sql.*;


public class Test {

	/**
	 * @param args
	 */
	
	//创建驱动
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
	//创建url
	static final String DB_URL_1 = "jdbc:mysql://localhost/";
	static final String DB_URL_2 = "jdbc:mysql://localhost/test";

	//信息
	static final String USER = "root";
	static final String PASS = "123456";
	   
	public static void main(String[] args) {
		
		Connection conn = null;
		Statement stmt = null;
		String sql = "";
		ResultSet rs = null;
		
		try{
//			//注册及链接
//			Class.forName(JDBC_DRIVER);
//			conn = DriverManager.getConnection(DB_URL_1,USER,PASS);
//
//			//创建数据库
//			String sql = "create database test";
//			stmt = conn.createStatement();
//			stmt.executeUpdate(sql);
			
//			//注册及链接
//			Class.forName(JDBC_DRIVER);
//			conn = DriverManager.getConnection(DB_URL_2,USER,PASS);

//			//创建表
//			stmt = conn.createStatement();
//			sql = "create table student" +
//			             "(id varchar(10) not null," +
//			             "name varchar(10) not null," +
//			             "age integer not null," +
//			             "sex boolean not null," +
//			             "primary key(id))";
//			stmt.executeUpdate(sql);
//
//			sql = "create table grade" +
//			             "(id varchar(10) not null," +
//			             "g_id varchar(10) not null," +
//			             "name varchar(10) not null," +
//			             "score integer)";
//			stmt.executeUpdate(sql);
//
//			//插入更新数据
//			stmt = conn.createStatement();
//			sql = "insert into student" + 
//						 " values ('001','Tom',20,1)";
//			stmt.executeUpdate(sql); 
//			sql = "insert into student" + 
//			             " values ('002','Lina',19,0)";
//			stmt.executeUpdate(sql); 
//			sql = "insert into student" + 
//			             " values ('003','Sb',21,1)";
//			stmt.executeUpdate(sql); 
//			sql = "update student set age = 18" + 
//			             " where id = '003'";
//			stmt.executeUpdate(sql); 
//
//            sql = "insert into grade" + 
//			             " values ('001','01','java',90)";
//			stmt.executeUpdate(sql); 
//			sql = "insert into grade(id,g_id,name)" + 
//			             " values ('001','02','c++')";
//			stmt.executeUpdate(sql); 
//			sql = "insert into grade(id,g_id,name)" + 
//			             " values ('002','01','java')";
//			stmt.executeUpdate(sql);
//			sql = "insert into grade" + 
//			             " values ('002','02','c++',89)";
//			stmt.executeUpdate(sql); 
//			sql = "insert into grade" + 
//			             " values ('003','02','c++',96)";
//			stmt.executeUpdate(sql); 

			
			//注册及链接
			Class.forName(JDBC_DRIVER);
			conn = DriverManager.getConnection(DB_URL_2,USER,PASS);
			stmt = conn.createStatement();
			
			//查询数据
			System.out.println("查询一；");
			sql = "select * from student";
			rs = stmt.executeQuery(sql);

			while(rs.next()){
				System.out.println("id:" + rs.getString("id") + "\t\t" +
					               "name:" + rs.getString("name") + "\t\t" +
					               "age:" + rs.getInt("age") + "\t\t" + 
					               "sex:" + rs.getInt("sex"));
			}
            
            System.out.println("查询二：");
            sql = "select * from grade";
            rs = stmt.executeQuery(sql);

            while(rs.next()){
				System.out.println("id:" + rs.getString("id") + "\t\t" +
					               "g_id" + rs.getString("g_id") + "\t\t" +
					               "name:" + rs.getString("name") + "\t\t" +
					               "score:" + rs.getInt("score"));
			}

            System.out.println("查询三：");
            sql = "select s.name as name,g.name as subject,g.score as score" +
            	  " from student s left join grade g on s.id = g.id";
            rs = stmt.executeQuery(sql);
            
            while(rs.next()){
				System.out.println("name:" + rs.getString("name") + "\t\t" +
					               "subject:" + rs.getString("subject") + "\t\t" + 
					               "score:" + rs.getInt("score"));
			}

		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try{
				if(stmt != null) stmt.close();
			}catch(Exception e){
				e.printStackTrace();
			}

			try{
				if(conn != null) conn.close();
			}catch(Exception e){
				e.printStackTrace();
			}
		}

		System.out.println("end");
		
	}

}
