public class test{

	/*
	45度旋转矩阵（对角线）
	如：
	                3
		1 2 3       2 6
		4 5 6  -->  1 5 9
		7 8 9       4 8
	                8
	 */



	public static void main(String[] args) {

		test t = new test();
		t.f(3);
	}

	public void f(int n){
        int k = 1;
		int [][]matrix = new int [n][n];

		for(int i = 0; i < n; i ++){
			for(int j = 0; j < n; j ++){
				matrix[i][j] = k ++;
			}
		}

		for(int i = 0, j = n - 1; i < n; ){
			while(j >= 0){
				int ii = i, jj = j;
				while(ii < n && jj < n){
					System.out.print(matrix[ii++][jj++] + " ");
				}
				System.out.println();
				j --;
			}
			

			i ++;j = 0;
		}
	}


}