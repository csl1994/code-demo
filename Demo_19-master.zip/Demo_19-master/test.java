public class test{

	public static void main(String[] args) {
		test t = new test();

		int [] array_1 = {9,6,1,7,3,2};
        int [] array_2 = {9,6,1,7,3,2};

		System.out.println("Recursion");
		t.Sort_1(array_1, 0, array_1.length - 1);
		for(int i = 0; i < array_1.length; i ++){
			System.out.print(array_1[i] + " ");
		}
		System.out.println();

		System.out.println("NoRecursion");
		t.Sort_2(array_2);
		for(int i = 0; i < array_2.length; i ++){
			System.out.print(array_2[i] + " ");
		}

        System.out.println();
		System.out.println("end");
	}

	public void Sort_1(int[] array, int low, int high){
		int mid = (low + high) / 2;
		if(low < high){
			Sort_1(array, low, mid);
			Sort_1(array, mid + 1, high);
			Merge(array, low, mid, high);
		}
	}

    public void Sort_2(int [] array){

		int size = 1;
		int low, mid, high;

		while(size < array.length){
			low = 0;
			while(low + size < array.length){
				mid = low + size - 1;
				high = mid + size;
				if(high > array.length - 1){
					high = array.length - 1;
				}
				Merge(array, low, mid, high);
				//System.out.println("low" + low + "high" + high);
				low = high + 1;
			}
			size *= 2;
		}

	}

	public void Merge(int [] array, int low, int mid, int high){
		int [] temp = new int [high - low + 1];
		int i = low;
		int j = mid + 1;
		int k = 0;
		while(i <= mid && j <= high){
			if(array[i] < array[j]){
				temp[k ++] = array[i ++];
			}
			else{
				temp[k ++] = array[j ++];
			}
		}

		while(i <= mid){
			temp[k ++] = array[i ++];
		}
		while(j <= high){
			temp[k ++] = array[j ++];
		}

		for(int l = 0; l < temp.length; l ++){
			array[l + low] = temp[l];
		}
	}


}