public class Test{

	public static void main(String[] args) {
		Test t = new Test();
		String str = new String("123");

		System.out.println("�ַ����");
		t.combine_1(str);
		System.out.println("�ַ�ȫ����");
		t.listAll("", new StringBuffer(str));
	}

	public void combine_1(String str){

		for(int i = 1; i <= str.length(); i ++){
			StringBuffer re = new StringBuffer();
			combine_2(str, 0, i, re);
		}
	}

	public void combine_2(String str, int i,int m, StringBuffer re){

		if(m == 0){
			System.out.println(re);
			return;
		}

		if(i == str.length()){
			return;
		}
		

		re.append(str.charAt(i));
		combine_2(str, i + 1, m - 1, re);
		re.deleteCharAt(re.length() - 1);
		combine_2(str, i + 1, m, re);
	}

	public void listAll(String re, StringBuffer str){
		if(str.length() == 0){
			System.out.println(re);
		}

		for(int i = 0; i < str.length(); i ++){
			StringBuffer tmp = new StringBuffer(str);
			listAll(re + tmp.charAt(i), tmp.deleteCharAt(i));
		}
	}
}
















