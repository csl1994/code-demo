import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Test{

	public static void main(String[] args) {

		String data = "asnfuhefkejfkafkdiohfankljdfkkij";

		HashMap<Character, Integer> map = new HashMap<Character, Integer>();

		for(int i = 0; i < data.length(); i ++){

			if(map.containsKey(data.charAt(i))){
				map.put(data.charAt(i), map.get(data.charAt(i)) + 1);
			}
			else{
				map.put(data.charAt(i), 1);
			}
		}

        List<Map.Entry<Character, Integer>> list = new
        ArrayList<Map.Entry<Character, Integer>>(map.entrySet());

        Collections.sort(list, new EntryComparator());
        //System.out.println(list.toString());
        
        int max = list.get(0).getValue().intValue();
        for(int i = 0; i < list.size(); i ++){
        	if(max > list.get(i).getValue().intValue()){
        		break;
        	}
        	else{
        		System.out.println(list.get(i).getKey() + " : " + max);
        	}
        }

        
    }


    static class EntryComparator implements Comparator<Map.Entry<Character, Integer>> {

	    public EntryComparator() {}
	    public int compare(Map.Entry<Character, Integer> o1, Map.Entry<Character, Integer> o2) {
	        //return o1.getValue().intValue() - o2.getValue().intValue();
	        return o2.getValue().intValue() -o1.getValue().intValue();//����

	    }

    }


    

}









