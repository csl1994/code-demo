
public class Graph {
	
	//����ͼ���ڽӱ�
	final boolean VISITED = true;
	final boolean UNVISITED = false;
	final int INFINITY = 1000;
	
	//�ڵ���
	private int vNum;
	//�ڽӾ���
	private int [][] matrix;
	//����Ƿ����
	private boolean [] mark;
	//ԭ�㵽��ÿ�������·������
	private int [] D;
	//������������ǰ��		
	private int [] Path;
	
	private class Edge{
		public int start,end,weight;
		
		public Edge(){}
		
	}
	
	public Graph(int vNum){
		this.vNum = vNum;
		matrix = new int [vNum][vNum];
		mark = new boolean [vNum];
		D = new int[vNum];
		Path = new int[vNum];
		for(int i = 0; i < vNum; i ++){
			mark[i] = UNVISITED;
			D[i] = INFINITY;
			Path[i] = -1;
			for(int j = 0; j < vNum; j ++){
				matrix[i][j] = 0; 
			}
		}
	}
	
	public void setEdge(int start, int end, int weight){
		matrix[start][end] = weight;
	}
	
	public boolean IsEdge(Edge oneEdge){
		if(oneEdge != null && oneEdge.weight == matrix[oneEdge.start][oneEdge.end]){
			return true;
		}
		return false;
	}
	
	public Edge NextEdge(Edge oneEdge){
		
		Edge next = new Edge();
		next.start = oneEdge.start;
		next.end = oneEdge.end;
		for(int j = oneEdge.end + 1; j < vNum; j ++){
			
			if(matrix[oneEdge.start][j] != 0){
				next.end = j;
				next.weight = matrix[oneEdge.start][j];
				return next;
			}
		}
		return next;
	}
	
	public Edge FirstEdge(int v){
		Edge first = new Edge();
		first.start = v;
		for(int j = 0; j < vNum; j ++){
			if(matrix[v][j] != 0){
				first.end = j;
				first.weight = matrix[v][j];
				return first;
			}
		}
		return null;
	}

	public void Dijkstra(int s){
		
		int n = vNum;
		int i, j;
		for(i = 0; i < n; i ++){
			mark[i] = UNVISITED;
			D[i] = INFINITY;
			Path[i] = -1;
		}

		mark[s] = VISITED;
		D[s] = 0;
		Path[s] = s;

		for(i = 0; i < vNum; i ++){
			//ȷ�����·��
			int min = D[i];
			int k = 0;
			for(j = 1; j < n; j ++){
				if(mark[j] == UNVISITED && min > D[j]){
					min = D[j];
					k = j;
				}
			}

			mark[k] = VISITED;


			//�����ѷ��ʶ������·������
			Edge e = FirstEdge(k);
			for(int ii = 0; ii < vNum; ii ++, e = NextEdge(e)){
				int v = e.end;
				if(IsEdge(e) && mark[v] == UNVISITED && D[v] > D[k] + e.weight){
					D[v] = D[k] + e.weight;
					Path[v] = k;
				}
			}
		}
		
		show(s);

		
	}
	
	public void show(int s){
		

		for(int i = 0; i < vNum; i ++){
			if(i != s){
				System.out.print("V" + s + "->" + "V" + i + ":");
				printPath(s, i);
				System.out.println("");
			}
		}
	}

	public void printPath(int s, int v){
		
		if(v == s){
			System.out.print("V" + s);
			return ;
		}
		else{
			printPath(s,Path[v]);
			System.out.print("-->V" + v);
			
		}
		
	}
		
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("action");
		Graph graph = new Graph(6);

		graph.setEdge(0, 1, 12);
		graph.setEdge(0, 2, 10);
		graph.setEdge(0, 4, 30);
		graph.setEdge(0, 5, 100);
		graph.setEdge(1, 2, 5);
		graph.setEdge(2, 3, 50);
		graph.setEdge(3, 5, 10);
		graph.setEdge(4, 3, 20);
		graph.setEdge(4, 5, 60);

		graph.Dijkstra(0);
		System.out.println("end");
		

	}

}