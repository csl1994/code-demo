import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;


public class Graph {
	
	//����ͼ���ڽӱ�
	final boolean VISITED = true;
	final boolean UNVISITED = false;
	
	private int length;
	private int [][] matrix;
	private boolean [] mark;
	
	private class Edge{
		public int start,end,weight;
		
		public Edge(){
			
		}


		
	}
	
	public Graph(int length){
		this.length = length;
		matrix = new int [length][length];
		mark = new boolean [length];
		for(int i = 0; i < length; i ++){
			mark[i] = UNVISITED;
			for(int j = 0; j < length; j ++){
				matrix[i][j] = 0; 
			}
		}
	}
	
	public void setEdge(int start, int end, int weight){
		matrix[start][end] = matrix[end][start] = weight;
	}
	
	public boolean IsEdge(Edge oneEdge){
		if(oneEdge.weight > 0)
			return true;
		return false;
	}
	
	public Edge NextEdge(Edge oneEdge){
		Edge next = new Edge();
		next.start = oneEdge.start;
		for(int j = oneEdge.end + 1; j < length; j ++){
			if(matrix[oneEdge.start][j] != 0){
				next.end = j;
				next.weight = oneEdge.weight;
				return next;
			}
		}
		return next;
	}
	
	public Edge NextEdge_2(Edge oneEdge){
		Edge next = new Edge();
		next.start = oneEdge.start;
		for(int j = length - 1; j > oneEdge.end; j --){
			if(matrix[oneEdge.start][j] != 0 && mark[j] == UNVISITED){
				next.end = j;
				next.weight = oneEdge.weight;
				return next;
			}
		}
		return next;
	}
	
	public Edge FirstEdge(int v){
		Edge first = new Edge();
		first.start = v;
		for(int j = 0; j < length; j ++){
			if(matrix[v][j] != 0){
				first.end = j;
				first.weight = matrix[v][j];
				return first;
			}
		}
		return first;
	}
	
	public Edge FirstEdge_2(int v){
		//�ҵ���һ��δ���ʵĽڵ�ı�
		Edge first = new Edge();
		first.start = v;
		for(int j = 0; j < length; j ++){
			if(matrix[v][j] != 0 && mark[j] == UNVISITED){
				first.end = j;
				first.weight = matrix[v][j];
				return first;
			}
		}
		return first;
	}

	public void DFS(int v){
		
		//�ݹ�
		mark[v] = VISITED;
		visit(v);
		for(Edge e = FirstEdge(v); IsEdge(e); e = NextEdge(e)){
			if(mark[e.end] == UNVISITED){
				DFS(e.end);
			}
		}
	}
	
	public void DFSTreverse(){
		for(int i = 0; i < length; i ++){
			mark[i] = UNVISITED;
		}
		
		for(int i = 0; i < length; i ++){
			if(mark[i] == UNVISITED){
				DFS(0);
			}	
		}
	}
	
	public void DFSNoReverse_1(){
		
		//���еķǵݹ�˼·
		int i,v,u;
		Stack<Integer> stack = new Stack<>();
		for(i = 0; i < length; i ++){
			mark[i] = UNVISITED;
		}
		
		for(i = 0; i < length; i ++){
			if(mark[i] == UNVISITED){
				stack.push(i);
				visit(i);
				mark[i] = VISITED;
				while(!stack.isEmpty()){
					v = stack.pop().intValue();
					for(Edge e = FirstEdge(v); IsEdge(e); e = NextEdge(e)){
						u = e.end;
						if(mark[u] == UNVISITED){
							stack.push(u);
							visit(u);
							mark[u] = VISITED;
						}
					}
				}
			}
		}
	}
	
    private void DFSNoReverse_2() {  
        // ���ϵĴ���İ棬http://blog.csdn.net/collonn/article/details/17923851
        int i,k = -1;  
        Stack<Integer> stack = new Stack<>();
		for(i = 0; i < length; i ++){
			mark[i] = UNVISITED;
		}
		stack.push(0);
		mark[0] = VISITED;  
	    visit(0);
        while(!stack.empty()){  
            k = stack.peek().intValue();  
            boolean needPop = true;  
            for(i = 0; i < length; i++){  
                if(matrix[k][i] != 0 && mark[i] == UNVISITED){  
                    stack.push(i);  
                    mark[i] = VISITED;  
                    visit(i);
                    needPop = false;  
                    break;  
                }  
            }  
            if(needPop){  
                stack.pop();  
            }  
        }  
    }  
	
	public void DFSNoReverse_3(){
		
		//�Լ���ķǵݹ飬�е㸴�Ӷ��Ҳ���
		Edge tmp = new Edge();
		int i,v;
		Stack<Integer> stack = new Stack<>();
		for(i = 0; i < length; i ++){
			mark[i] = UNVISITED;
		}
		
		for(i = 0; i < length; i ++){
			if(mark[i] == UNVISITED){
				stack.push(i);
				visit(i);
				mark[i] = VISITED;
				v = i;
				while(!stack.isEmpty()){
					stack.pop();
					tmp = FirstEdge_2(v);
					if(mark[tmp.end] == UNVISITED){
						v = tmp.end;
						visit(v);
						mark[v] = VISITED;
					}else{
						if(!stack.isEmpty())
							v = stack.pop();
						else{
							break;
						}
					}
					tmp = NextEdge_2(tmp);
					while(IsEdge(tmp)){
						stack.push(tmp.end);
						tmp = NextEdge(tmp);
					}
					stack.push(v);
				}
			}
		}
	}
	
	public void BFS_1(int v){
			
		//����˼·
		Queue<Integer> queue = new LinkedList<Integer>();
		mark[v] = VISITED;
		visit(v);
		queue.offer(v);
		while(!queue.isEmpty()){
			v = queue.poll().intValue();
			for(Edge e = FirstEdge(v); IsEdge(e); e = NextEdge(e)){
				int u = e.end;
				if(mark[u] == UNVISITED){
					visit(u);
					mark[u] = VISITED;
					queue.offer(u);
				}
			}
		}
	}
	
	public void BFS_2(int v){
		
		//�Լ�д��
		Queue<Integer> queue = new LinkedList<Integer>();
		mark[v] = VISITED;
		visit(v);
		queue.offer(v);
		while(!queue.isEmpty()){
			v = queue.poll().intValue();
			for(int i = 0; i < length; i++){  
                if(matrix[v][i] != 0 && mark[i] == UNVISITED){  
                    queue.offer(i); 
                    mark[i] = VISITED;  
                    visit(i);
                }  
            }  
		}
	}
	
	
	public void BFSNoReverse(){
		for(int i = 0; i < length; i ++){
			mark[i] = UNVISITED;
		}
		
		for(int i = 0; i < length; i ++){
			if(mark[i] == UNVISITED){
				BFS_1(i);
			}
		}
	}
	
	public void visit(int v){
		System.out.print("V" + (v + 1) + " ");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Graph graph = new Graph(8);
		graph.setEdge(0, 1, 1);
		graph.setEdge(0, 2, 1);
		graph.setEdge(1, 3, 1);
		graph.setEdge(1, 4, 1);
		graph.setEdge(3, 7, 1);
		graph.setEdge(4, 7, 1);
		graph.setEdge(2, 5, 1);
		graph.setEdge(2, 6, 1);
		graph.setEdge(5, 6, 1);
		
		System.out.println("kinds of dfs");
		
		graph.DFSTreverse();
		System.out.println("end");
		
		graph.DFSNoReverse_2();
		System.out.println("end");
		
		graph.DFSNoReverse_3();
		System.out.println("end");
		
		
		System.out.println("bfs");
		
		graph.BFSNoReverse();
		System.out.println("end");
		
		
		Graph g = new Graph(5);
		g.setEdge(0, 1, 1);
		g.setEdge(1, 2, 1);
		g.setEdge(2, 0, 1);
		g.setEdge(0, 3, 1);
		g.setEdge(2, 4, 1);
		g.setEdge(3, 4, 1);
		g.setEdge(1, 4, 1);
		


	}

}
