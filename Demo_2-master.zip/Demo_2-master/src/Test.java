
public class Test {

	/**
	 * @param args
	 * ��������
	 * ϣ������
	 * ��С����
	 */
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] array1 = {3,5,6,1,7,9,5,1}; 
		show(array1);
		System.out.println("��������");
		InsertSort(array1);
		
		int [] array2 = {3,5,6,1,7,9,5,1};
		show(array2);
		System.out.println("ϣ������");
		ShellSort(array2);

	}

	//��������
	public static void InsertSort(int [] array){
		
		for(int i = 1; i < array.length; i ++){
			if(array[i] < array[i - 1]){
				int temp = array[i];
				int j = i - 1;
				while(j >= 0 && temp < array[j]){
					array[j + 1] = array[j];
					j --;
				}
				array[j + 1] = temp;
				show(array);
			}
		}
		
	}
	
	//ϣ������
	public static void ShellSort(int [] array){
		int flag = array.length / 2;
		while(flag >= 1){
			ShellInsertSort(array, flag);
			flag = flag / 2;
		}
	}
	
	public static void ShellInsertSort(int [] array, int flag){
		
		for(int i = flag; i < array.length; i ++){
			if(array[i] < array[i - flag]){
				int j = i - flag;
				int temp = array[i];
				//array[i] = array[i - flag];
				while(j >= 0 && temp < array[j]){
					array[j + flag] = array[j];
					j -= flag;
				}
				array[j + flag] = temp;
				show(array);
			}
		}
	}
	
	//���
	public static void show(int [] array){
		
		for(int i = 0; i < array.length; i ++){
			System.out.print(array[i] + " ");
		}
		System.out.println("");
	}
}
