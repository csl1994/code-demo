import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;

public class MaxHeap {
	
	private ArrayList<Integer> heapArray;
	private int currentSize;

	public MaxHeap(int []  heapArray, int currentSize) {
		this.heapArray = new ArrayList<Integer>();
		this.currentSize = currentSize;
		for(int i = 0; i < currentSize; i ++){
			this.heapArray.add(heapArray[i]);
		}
		
	}

	public void BuildHeap(){
		for(int i = currentSize / 2 - 1; i >= 0; i --){
			SiftDown(i);
		}
	}
	
	public void SiftDown(int left){
		int i = left;
		int j = 2 * i + 1;
		int temp = heapArray.get(i);
		
		while(j < currentSize){
			if(j < currentSize - 1 && heapArray.get(j) < heapArray.get(j + 1)){
				j ++;
			}
			if(temp < heapArray.get(j)){
				heapArray.set(i, heapArray.get(j));
				i = j;
				j = 2 * i + 1;
			}
			else{
				break;
			}
		}
		heapArray.set(i, temp);
	}
	
	public void deleteItem(int pos){
		if(pos >= currentSize){
			return ;
		}
		else{
			int temp = heapArray.get(pos);
			heapArray.set(pos, heapArray.get(currentSize - 1));
			heapArray.remove(currentSize - 1);
			currentSize --;
			if(currentSize > 1){
				SiftDown(0);
			}
		}
	}
	
	public void insertData(int data){
		heapArray.add(data);
		currentSize ++;
		BuildHeap();
	}

	public void show(){
		
		for(Iterator i = heapArray.iterator();i.hasNext(); ){
			Integer ii = (Integer) i.next();
			System.out.print(ii + "  ");
		}
		System.out.println("");
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//ʹ�õ�˳��洢
		int array [] = {20, 12, 35, 15, 10, 80, 30, 17, 2, 1};
		MaxHeap mh = new MaxHeap(array, array.length);
		mh.BuildHeap();
		mh.show();
		
//		mh.deleteItem(0);
//		mh.show();
		
//		mh.insertData(40);
//		mh.show();
		
		System.out.println("end");
	}

}
