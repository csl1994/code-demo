
public class Test {

	/**
	 * @param args
	 * ע��swap������������C++��һ��ʹ������
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int [] array1 = {2,1,3,4,6,3,7,1,9};
		show(array1);
		System.out.println("ð������");
		BubbleSort(array1);
		System.out.println("");
		int [] array2 = {2,4,5,1,6,7,8,1,4,0};
		show(array2);
		System.out.println("��������");
		QuickSort(array2, 0, array2.length - 1);

	}
	
	//ð������
	public static void BubbleSort(int [] array){
		int temp = 0;
		
		for(int i = 0; i < array.length; i ++){
			for(int j = i; j < array.length - 1; j ++){
				if(array[i] > array[j + 1]){
					temp = array[j + 1];
					array[j + 1] = array[i];
					array[i] = temp;
					show(array);
				}
			}
		}
	}
	
	//����
	public static void swap(int [] array, int a, int b){
		int temp = array[a];
		array[a] = array[b];
		array[b] = temp;
	}
	public static int partition(int [] array, int low, int high){
		int privotKey = array[low];
		while(low < high){
			while(low < high && array[high] >= privotKey){
				high --;
			}
			swap(array, low, high);
			
			while(low < high && array[low] <= privotKey){
				low ++;
			}
			swap(array, low, high);
		}
		show(array);
		return low;
	}
	public static void QuickSort(int [] array, int low, int high){
		if(low < high){
			int privotLoc = partition(array, low, high);
			QuickSort(array, low, privotLoc - 1);
			QuickSort(array, privotLoc + 1, high);
		}
	}
	
	//���
	public static void show(int [] array){
		
		for(int i = 0; i < array.length; i ++){
			System.out.print(array[i] + " ");
		}
		System.out.println("");
	}

}
