﻿namespace Training03
{
    #region using directives
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Text;
    #endregion
    public class MyStack<T> : IStack<T>
    {
        private List<T> myStack;
        private List<Int32> forEachIndex;
        private List<Int32> forEachStackCount;
        private Int32 currentForEach;

        public Int32 Count
        {
            get
            {
                return this.myStack.Count;
            }
        }

        #region Basic Method and IStack
        public MyStack()
        {
            this.myStack = new List<T>();
            this.forEachIndex = new List<Int32>();
            this.forEachStackCount = new List<Int32>();
            this.currentForEach = 0;
        }
        public void Empty()
        {
            if (this.Count > 0)
            {
                this.myStack.Clear();
            }
            else
            {
                throw new Exception("The stack is empty.");
            }
            
        }

        public T Peek()
        {
            if (this.Count <= 0)
            {
                throw new Exception("The stack is empty.");
            }
            T topItem = this.myStack[this.Count - 1];
            return topItem;
        }

        public T Pop()
        {
            if (this.Count <= 0)
            {
                throw new Exception("The stack is empty.");
            }
            T topItem = this.myStack[this.Count - 1];
            this.myStack.RemoveAt(this.Count - 1);
            return topItem;
        }

        public void Push(T item)
        {
            myStack.Add(item);
        }

        public override String ToString()
        {
            StringBuilder stackItems = new StringBuilder();
            for(var count = this.Count - 1; count > 0; count--)
            {
                stackItems.Append(this.myStack[count]);
                stackItems.Append("\n");
            }
            stackItems.Append(this.myStack[0]);
            return stackItems.ToString();
        }

        public Boolean IsEmpty()
        {
            return this.Count == 0;
        }
        #endregion

        #region IEnumerable and IEnumerator
        public IEnumerator<T> GetEnumerator()
        {
            this.forEachIndex.Add(this.Count);
            this.currentForEach = this.forEachIndex.Count;
            if(currentForEach > 1)
            {
                this.forEachStackCount.Add(this.forEachStackCount[0]);
            }
            else
            {
                this.forEachStackCount.Add(this.Count);
            }
            return this;
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            this.forEachIndex.Add(this.Count);
            this.currentForEach = this.forEachIndex.Count;
            return this.GetEnumerator();
        }

        public T Current
        {
            get
            {
                return this.myStack[this.forEachIndex[currentForEach - 1]];
            }
        }

        object IEnumerator.Current
        {
            get
            {
                return this.Current;
            }
        }

        public void Dispose()
        {
            this.forEachIndex.RemoveAt(currentForEach - 1);
            this.forEachStackCount.RemoveAt(currentForEach - 1);
            this.currentForEach = this.forEachIndex.Count;
        }

        public bool MoveNext()
        {
            if(this.forEachStackCount[currentForEach - 1] != this.Count)
            {
                throw new Exception("When foreach stack can not modify.");
            }
            return  --this.forEachIndex[currentForEach - 1] >= 0;
        }

        public void Reset()
        {
            this.forEachIndex.RemoveAt(currentForEach - 1);
            this.currentForEach = this.forEachIndex.Count;
        }
        #endregion
    }
}
