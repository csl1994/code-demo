﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TicketBox
{
    public class  TicketInfo
    {
        private static List<string> ticketList = new List<string>() 
        {
            "T1","T2","T3","T4","T5","T6","T7","T8","T9","T10",
            "T11","T12","T13","T14","T15","T16","T17","T18","T19","T20",
            "T21","T22","T23","T24","T25","T26","T27","T28","T29","T30",
            "T31","T32","T33","T34","T35","T36","T37","T38","T39","T40",
            "T41","T42","T43","T44","T45","T46","T47","T48","T49","T50"
        };
    }
}
