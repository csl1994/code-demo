﻿namespace Training04
{

    #region using directives
    using FactoryTest;
    using SellTicketTest;
    using System;
    using System.Threading;
    #endregion
    public class Program
    {
        static void Main(string[] args)
        {
            try
            {
                //Console.WriteLine("Press enter test factory process.");
                //Console.ReadLine();
                ////使用默认生产，销售次数
                //var myFactory = new Factory();
                //myFactory.FactoryActive();

                //自定义生产，销售次数
                //Int32 productCount;
                //Int32 sellCount;
                //do
                //{
                //    Console.WriteLine("Input tow numbers(both>0),one is product count,another is sell count.");
                //    Console.Write("first:");
                //    productCount = Convert.ToInt32(Console.ReadLine());
                //    Console.Write("second:");
                //    sellCount = Convert.ToInt32(Console.ReadLine());
                //}
                //while (productCount <= 0 || sellCount <= 0);
                //var myFactory = new Factory(productCount, sellCount);
                //myFactory.FactoryActive();

                //Thread.Sleep(10000);

                Console.WriteLine("\nPress enter test sell tickets process.");
                Console.ReadLine();
                var mySell = new SellTicket();
                mySell.SellStart();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
            finally
            {
                Console.ReadLine();
            }
        }
    }
}
