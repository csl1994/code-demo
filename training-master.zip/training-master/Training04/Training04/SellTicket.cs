﻿namespace SellTicketTest
{
    #region using directives
    using System;
    using System.Collections.Generic;
    using System.Reflection;
    using System.Threading;
    #endregion
    public class SellTicket
    {
        private readonly Object sync = new Object();
        private List<String> ticketPool;
        private Int32 currentNum;
        private Boolean sellState = true;

        public SellTicket()
        {
            Assembly assembly = Assembly.LoadFrom("TicketBox.dll");
            object obj = assembly.CreateInstance("TicketBox.TicketInfo");
            Type type = obj.GetType();
            FieldInfo fieldinfo = type.GetField("ticketList", BindingFlags.NonPublic | BindingFlags.Static);
            this.ticketPool = (List<String>)fieldinfo.GetValue(null);
        }
        public void SellStart()
        {
            for (Int32 windowCount = 0; windowCount < 10; windowCount++)
            {
                Thread windowThread = new Thread(() =>
                {
                    try
                    {
                        this.Sell();
                    }
                    catch(Exception e)
                    {
                        throw;
                    }
                });
                windowThread.Name = "Window_" + windowCount;
                windowThread.Start();
            }
        }

        public void Sell()
        {
            while (this.sellState)
            {
                lock (this.sync)
                {
                    if (this.currentNum < this.ticketPool.Count)
                    {
                        Console.WriteLine("{0} : {1}--{2}.", Thread.CurrentThread.Name, this.ticketPool[currentNum++],
                            DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss"));
                        Thread.Sleep(new Random().Next(500, 1000));
                    }
                    else
                    {
                        Console.WriteLine("No tickets.");
                        this.sellState = false;
                    }
                }
            }
        }
    }
}
