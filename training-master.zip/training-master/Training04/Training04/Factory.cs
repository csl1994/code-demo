﻿namespace FactoryTest
{
    #region using directives
    using System;
    using System.Threading;
    #endregion
    public class Factory
    {
        private readonly Object sync = new Object();
        private readonly Int32 maxGoods = 10;
        private readonly Int32 minGoods = 0;
        private Int32 currentGoods = 0;
        private Int32 productCount;
        private Int32 sellCount;
        private Boolean isPorduct = true;
        private Boolean isSell = true;

        //默认生产15次，销售20次
        public Factory()
        {
            this.productCount = 15;
            this.sellCount = 20;
        }

        public Factory(Int32 productCount, Int32 sellCount)
        {
            this.productCount = productCount;
            this.sellCount = sellCount;
        }

        public void FactoryActive()
        {
            var productActive = new Thread(() =>
            {
                try
                {
                    this.Product();
                }
                catch (Exception e)
                {
                    throw;
                }
            });
            var sellActive = new Thread(() =>
            {
                try
                {
                    this.Sell();
                }
                catch (Exception e)
                {
                    throw;
                }
            });
            productActive.Name = "Product";
            sellActive.Name = "Sell";
            productActive.Start();
            sellActive.Start();
        }

        public void Product()
        {
            for (Int32 count = 0; count < this.productCount; count++)
            {
                lock (this.sync)
                {
                    if (isPorduct)
                    {
                        if (this.currentGoods < this.maxGoods)
                        {
                            Console.WriteLine("{0} count {1} : Current goods is {2}.", Thread.CurrentThread.Name,
                                (count + 1), ++this.currentGoods);
                            isSell = true;
                        }
                        else
                        {
                            Console.WriteLine("{0} count {1} : The stroe is full.", Thread.CurrentThread.Name, (count + 1));
                            isPorduct = false;
                        }
                    }
                    
                }
                Thread.Sleep(new Random().Next(100, 500));
            }
        }

        public void Sell()
        {
            for (Int32 count = 0; count < this.sellCount; count++)
            {
                lock (this.sync)
                {
                    if (isSell)
                    {
                        if (this.currentGoods > this.minGoods)
                        {
                            Console.WriteLine("{0} count {1}: Current goods is {2}.", Thread.CurrentThread.Name,
                               (count + 1), --this.currentGoods);
                            isPorduct = true;
                        }
                        else
                        {
                            Console.WriteLine("{0} count {1}: The store is empty.", Thread.CurrentThread.Name, (count + 1));
                            isSell = false;
                        }
                    }
                    
                }
                Thread.Sleep(new Random().Next(100, 500));
            }
        }
    }
}
