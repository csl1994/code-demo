﻿namespace Training03
{
    #region using directives
    using BCLHomework;
    using System;
    using System.Collections.Generic;
    #endregion
    class Program
    {
        static void Main(String[] args)
        {
            try
            {
                #region show stack
                var testStack = new MyStack<String>();
                testStack.Push("A");
                testStack.Push("B");
                testStack.Push("C");
                //Console.WriteLine("Show stack with ToString.\n{0}",testStack.ToString());
                //会输出C, 但是会报错。
                //foreach (var item1 in testStack)
                //{
                //    testStack.Push("D");
                //    Console.WriteLine(item1);
                //}
                //throw exception test
                //foreach (var item in testStack)
                //{
                //    testStack.Pop();
                //}
                //testStack.Empty();
                //testStack.Pop();
                //testStack.Peek();
                Console.WriteLine("Show stack with foreach.");
                foreach (var item in testStack)
                {
                    foreach (var item1 in testStack)
                    {
                        Console.WriteLine(item1);
                    }
                }
                testStack.Empty();
                #endregion

                #region build tree
                //var treeNode1 = new TreeNode();
                //treeNode1.Name = "A";
                //treeNode1.Value = 5;
                //var treeNode2 = new TreeNode();
                //treeNode2.Name = "B";
                //treeNode2.Value = 3;
                //var treeNode3 = new TreeNode();
                //treeNode3.Name = "C";
                //treeNode3.Value = 10;
                //var treeNode4 = new TreeNode();
                //treeNode4.Name = "D";
                //treeNode4.Value = 5;
                //var treeNode5 = new TreeNode();
                //treeNode5.Name = "E";
                //treeNode5.Value = 6;
                //var treeNode6 = new TreeNode();
                //treeNode6.Name = "F";
                //treeNode6.Value = 0;
                //var treeNode7 = new TreeNode();
                //treeNode7.Name = "A";
                //treeNode7.Value = 3;

                //treeNode1.AddChild(treeNode2);
                //treeNode1.AddChild(treeNode3);
                //treeNode2.AddChild(treeNode4);
                //treeNode2.AddChild(treeNode5);
                //treeNode3.AddChild(treeNode6);
                //treeNode3.AddChild(treeNode7);
                //Console.WriteLine("Show the tree.\n{0}", treeNode1.ToString());
                //#endregion

                //#region preorder without recusion
                //var nodeStack = new MyStack<TreeNode>();
                //var treeNode = treeNode1;
                //Console.WriteLine("Preorder without recusion.");
                //while (!nodeStack.IsEmpty() || !object.Equals(treeNode, null))
                //{
                //    if (!object.Equals(treeNode, null))
                //    {
                //        Console.WriteLine("{0}({1})", treeNode.Name, treeNode.Value);
                //        if (!treeNode.Children.Equals(null))
                //        {
                //            for (var count = treeNode.ChildrenCount; count > 1; count--)
                //            {
                //                nodeStack.Push(treeNode.Children[count - 1]);
                //            }
                //        }
                //        if (treeNode.ChildrenCount > 0)
                //        {
                //            treeNode = treeNode.Children[0];
                //        }
                //        else
                //        {
                //            treeNode = null;
                //        }
                //    }
                //    else
                //    {
                //        treeNode = nodeStack.Pop();
                //    }
                //}
                #endregion
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
            finally
            {
                Console.ReadLine();
            }
        }
    }
}
