﻿namespace Training03
{
    #region using directives
    using System;
    using System.Collections.Generic;
    #endregion
    interface IStack<T> : IEnumerable<T>, IEnumerator<T>
    {
        Int32 Count { get; }
        void Empty();
        T Peek();
        T Pop();
        void Push(T item);
        Boolean IsEmpty();

    }
}
