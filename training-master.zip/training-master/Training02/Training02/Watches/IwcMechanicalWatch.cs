﻿namespace Training02.Watches
{
    #region using directives
    using System;
    using Training02.WatchBases;
    #endregion
    class IwcMechanicalWatch : MechanicalWatchBase
    {
        public IwcMechanicalWatch(DateTime currentDateTime)
        {
            this.Name = "IWC";
            this.Advertisement = "源自瑞士沙夫豪森的非凡技术和精湛工艺.";
            this.SetDateTime(currentDateTime);
        }
        public override void ShowAbility()
        {
            this.PrintName();
            this.PrintDateTime();
            this.AutoWinding();
            this.PrintAdvertisement();
        }
    }
}
