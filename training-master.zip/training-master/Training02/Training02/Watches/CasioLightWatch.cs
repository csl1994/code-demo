﻿namespace Training02.Watches
{
    #region using directives
    using System;
    using Util;
    using WatchAbility;
    using WatchBases;
    #endregion
    class CasioLightWatch : LightWatchBase, IFindDateTime
    {
        public Int32 Interval { get; set; }
        public String findDateTime { get; set; }
        public CasioLightWatch(DateTime currentDateTime)
        {
            this.Name = "CASIO";
            this.Advertisement = "造就卓越品质的巅峰之作.天生玩固,唯我独行.先进技术,动感设计.";
            this.SetDateTime(currentDateTime);
        }
        public override void ShowAbility()
        {
            this.PrintName();
            this.PrintDateTime();
            this.PrintAdvertisement();
            this.FindDateTime(this.Interval);
        }
        public void FindDateTime(Int32 interval)
        {
            this.findDateTime = FindDateTimeHelper.FindDateTime(interval, this.Year, this.Month, this.Day).ToString("yyyy-M-d");
        }
    }
}
