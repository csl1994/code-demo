﻿namespace Training02.Watches
{
    #region using directives
    using System;
    using WatchBases;
    #endregion

    class RadoQuartzWatch : QuartzWatchBase
    {
        public RadoQuartzWatch(DateTime currentDateTime)
        {
            this.Name = "RADO";
            this.Advertisement = "戴雷达,走向世界.";
            this.SetDateTime(currentDateTime);
        }
        public override void ShowAbility()
        {
            this.PrintName();
            this.PrintDateTime();
            this.PrintAdvertisement();
        }
    }
}
