﻿namespace Training02.Watches
{
    #region using directives
    using System;
    using Training02.WatchAbility;
    using WatchBases;
    #endregion
    class TissotQuartzWatch : QuartzWatchBase, IStopWatch
    {
        public TissotQuartzWatch(DateTime currentDateTime)
        {
            this.Name = "TISSOT";
            this.Advertisement = "真我尽现.";
            this.SetDateTime(currentDateTime);
        }
        public override void ShowAbility()
        {
            this.PrintName();
            this.PrintDateTime();
            this.StopWatch();
            this.PrintAdvertisement();
        }

        public void StopWatch()
        {
            Console.WriteLine("I can StopWatch.");
        }
    }
}
