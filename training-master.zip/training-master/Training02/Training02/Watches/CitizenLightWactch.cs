﻿namespace Training02.Watches
{
    #region using directives
    using System;
    using WatchBases;
    #endregion
    class CitizenLightWactch : LightWatchBase
    {
        public CitizenLightWactch(DateTime currentDateTime)
        {
            this.Name = "CITIZEN";
            this.Advertisement = "光动能,汇聚万物之光,缔造和谐自然.";
            this.SetDateTime(currentDateTime);
        }
        public override void ShowAbility()
        {
            this.PrintName();
            this.PrintDateTime();
            this.PrintAdvertisement();
        }
    }
}
