﻿namespace Training02.Watches
{
    #region using directives
    using System;
    using Training02.WatchAbility;
    using WatchBases;
    #endregion

    class OmegaMechanicalWatch : MechanicalWatchBase, IStopWatch
    {
        public OmegaMechanicalWatch(DateTime currentDateTime)
        {
            this.Name = "OMEGA";
            this.Advertisement = "静让世界暂停,动让时间前行.";
            this.SetDateTime(currentDateTime);
        }
        public override void ShowAbility()
        {
            this.PrintName();
            this.PrintDateTime();
            this.StopWatch();
            this.AutoWinding();
            this.PrintAdvertisement();
        }

        public void StopWatch()
        {
            Console.WriteLine("I can StopWatch.");
        }
    }
}
