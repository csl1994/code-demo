﻿namespace Training02.WatchAbility
{
    #region using directives
    using System;
    #endregion
    public interface IFindDateTime
    {
        void FindDateTime(Int32 interval);
    }
}
