﻿namespace Training02.WatchAbility
{
    public interface IAutoWinding
    {
        void AutoWinding();
    }
}
