﻿namespace Training02.WatchAbility
{
    public interface IStopWatch
    {
        void StopWatch();
    }
}
