﻿namespace Training02.Util
{
    #region using directives
    using System;
    #endregion
    public class FindDateTimeHelper
    {
        private FindDateTimeHelper() { }
        public static readonly FindDateTimeHelper helper = new FindDateTimeHelper();

        public static FindDateTimeHelper getMyFindDateTimeHelper()
        {
            return helper;
        }

        public static DateTime FindDateTime(Int32 interval, Int32 year, Int32 month, Int32 day)
        {
            var isFound = default(Boolean);
            var checkResult = default(Boolean);
            var monthDayRow = 0;
            Int32[,] monthDay = new Int32[2, 12] {
            {31,28,31,30,31,30,31,31,30,31,30,31},
            {31,29,31,30,31,30,31,31,30,31,30,31}};

            if (interval >= 0 && year > 0 && (month > 0 && month < 13) && day > 0)
            {
                if (((year % 4 == 0 && year % 100 != 0) || year % 400 == 0) && month == 2)
                {
                    if (day < 30)
                    {
                        checkResult = true;
                    }
                }
                else if (month == 1 || month == 3 || month == 5 ||
                    month == 7 || month == 8 || month == 10 || month == 12)
                {
                    if (day < 32)
                    {
                        checkResult = true;
                    }
                }
                else
                {
                    if (day < 31)
                    {
                        checkResult = true;
                    }
                }
            }
            if (checkResult)
            {
                while (interval > 366)
                {
                    if (month > 2)
                    {
                        if (((year + 1) % 4 == 0 && (year + 1) % 100 != 0) || (year + 1) % 400 == 0)
                        {
                            year += 1;
                            interval -= 366;
                        }
                        else {
                            year += 1;
                            interval -= 365;
                        }
                    }
                    else {
                        if (((year + 1) % 4 == 0 && (year + 1) % 100 != 0) || (year + 1) % 400 == 0)
                        {
                            year += 1;
                            interval -= 365;
                        }
                        else {
                            year += 1;
                            interval -= 366;
                        }
                    }
                }
                if ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0)
                {
                    monthDayRow = 1;
                }
                else {
                    monthDayRow = 0;
                }
                while (!isFound)
                {
                    if (month > 12)
                    {
                        month = 1;
                        year += 1;
                    }
                    else if (month == 2)
                    {
                        if ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0)
                        {
                            monthDayRow = 1;
                        }
                        else {
                            monthDayRow = 0;
                        }
                        if ((monthDay[monthDayRow, month - 1] - day) >= interval)
                        {
                            day += interval;
                            isFound = true;
                        }
                        else
                        {
                            interval = interval - (monthDay[monthDayRow, month - 1] - day) - 1;
                            day = 1;
                            month += 1;
                        }
                    }
                    else {
                        if ((monthDay[monthDayRow, month - 1] - day) >= interval)
                        {
                            day += interval;
                            isFound = true;
                        }
                        else
                        {
                            interval = interval - (monthDay[monthDayRow, month - 1] - day) - 1;
                            day = 1;
                            month += 1;
                        }
                    }
                }
                return new DateTime(year, month, day);
            }
            else
            {
                throw new Exception("FindDateTimeHelper input parameter is error.");
            }

        }
    }
}
