﻿namespace Training02.WatchBases
{
    abstract class LightWatchBase : WatchBase
    {
    }
}
