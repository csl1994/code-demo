﻿namespace Training02.WatchBases
{
    #region using directives
    using System;
    #endregion
    public abstract class WatchBase
    {
        public String Name { get; set; }
        public String Advertisement { get; set; }
        public Int32 Year { get; set; }
        public Int32 Month { get; set; }
        public Int32 Day { get; set; }
        public Int32 Hour { get; set; }
        public Int32 Minute { get; set; }
        public Int32 Second { get; set; }
        public virtual void ShowAbility()
        {
            this.PrintName();
            this.PrintAdvertisement();
            this.PrintDateTime();
        }

        protected virtual void PrintAdvertisement()
        {
            if (!String.IsNullOrEmpty(this.Advertisement))
            {
                Console.WriteLine("My advertisement:");
                for (var printCount = 0; printCount < 5; printCount++)
                {
                    Console.WriteLine(this.Advertisement);
                }
            }
            else
            {
                throw new Exception("The watch do not have an advertisement.");
            }
        }

        protected virtual void PrintName()
        {
            if (!String.IsNullOrEmpty(this.Name))
            {
                Console.WriteLine("My name is {0}", this.Name);
            }
            else
            {
                throw new Exception("The watch has no name.");
            }

        }

        protected virtual void PrintDateTime()
        {
            if (this.CheckDateTime())
            {
                Console.WriteLine("Current datetime is {0}-{1}-{2} {3}:{4}:{5}", this.Year, this.Month,
                        this.Day, this.Hour, this.Minute, this.Second);
            }
            else
            {
                throw new Exception("Datetime is error");
            }
        }

        protected virtual void SetDateTime(DateTime currentDateTime)
        {
            this.Year = currentDateTime.Year;
            this.Month = currentDateTime.Month;
            this.Day = currentDateTime.Day;
            this.Hour = currentDateTime.Hour;
            this.Minute = currentDateTime.Minute;
            this.Second = currentDateTime.Second;
        }

        protected virtual Boolean CheckDateTime()
        {
            var checkResult = default(Boolean);
            if (this.Year > 0 && (this.Month > 0 && this.Month < 13) && this.Day > 0 &&
                (this.Hour >= 0 && this.Hour < 25) && (this.Minute >= 0 && this.Minute < 61) &&
                (this.Second >= 0 && this.Second < 61))
            {
                if (((this.Year % 4 == 0 && this.Year % 100 != 0) || this.Year % 400 == 0) && this.Month == 2)
                {
                    if (this.Day < 30)
                    {
                        checkResult = true;
                    }
                }
                else if (this.Month == 1 || this.Month == 3 || this.Month == 5 ||
                    this.Month == 7 || this.Month == 8 || this.Month == 10 || this.Month == 12)
                {
                    if (this.Day < 32)
                    {
                        checkResult = true;
                    }
                }
                else
                {
                    if (this.Day < 31)
                    {
                        checkResult = true;
                    }

                }

            }
            return checkResult;
        }
    }
}
