﻿namespace Training02.WatchBases
{
    #region using directives
    using System;
    using Training02.WatchAbility;
    #endregion
    abstract class MechanicalWatchBase : WatchBase, IAutoWinding
    {
        public void AutoWinding()
        {
            Console.WriteLine("I can autowinding.");
        }
    }
}
