﻿namespace Training02.WatchBases
{
    abstract class QuartzWatchBase : WatchBase
    {
    }
}
