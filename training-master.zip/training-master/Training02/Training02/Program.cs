﻿namespace Training02
{
    #region using directives
    using System;
    using System.Collections.Generic;
    using WatchBases;
    using Watches;
    #endregion

    class Program
    {
        static void Main(String[] args)
        {
            try
            {
                Console.WriteLine("----------程序测试----------");
                DateTime currentDateTime = DateTime.Now;
                var myWatch = new List<WatchBase>();
                myWatch.Add(new CitizenLightWactch(currentDateTime));
                myWatch.Add(new IwcMechanicalWatch(currentDateTime));
                myWatch.Add(new OmegaMechanicalWatch(currentDateTime));
                myWatch.Add(new RadoQuartzWatch(currentDateTime));
                myWatch.Add(new TissotQuartzWatch(currentDateTime));
                var myCasio = new CasioLightWatch(currentDateTime);
                Console.WriteLine("Input the Casio's interval(Int32)");
                myCasio.Interval = Convert.ToInt32(Console.ReadLine());
                myWatch.Add(myCasio);
                foreach(var watch in myWatch)
                {
                    watch.ShowAbility();
                    Console.WriteLine("----------分割线----------");
                }
                Console.WriteLine("after {0} days is {1}", myCasio.Interval,myCasio.findDateTime);
                DateTime dateTimeTest = DateTime.Now.AddDays(myCasio.Interval);
                Console.WriteLine("DateTime Class Test {0}", dateTimeTest.ToString("yyyy-M-d"));
                Console.WriteLine("----------测试结束----------");
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
            finally
            {
                Console.ReadLine();
            }
        }
    }
}
