﻿namespace Training06.Util
{
    #region using directives

    using System;
    using System.IO;
    using System.Text;

    #endregion using directives

    public enum LogLevel
    {
        INFO,
        WARNING,
        ERROR
    }

    public class LogUtil
    {
        private static readonly LogUtil helper = new LogUtil();
        private static String defaultLogPath = Environment.CurrentDirectory;

        public String LogPath
        {
            get
            {
                return defaultLogPath;
            }
            set
            {
                defaultLogPath = value;
            }
        }

        public String FileName
        {
            get
            {
                return String.Format("{0}{1}", LogPath, @"\logs.txt");
            }
        }
       
        private LogUtil() { }

        public static LogUtil GetLogUtil()
        {
            return helper;
        }

        public void WriteLog(LogLevel level,String information)
        {
            if (String.IsNullOrWhiteSpace(information))
            {
                throw new ArgumentException("The log information is error.");
            }
            if (!Directory.Exists(LogPath))
            {
                Directory.CreateDirectory(LogPath);
            }
            using (var logWriter = new StreamWriter(FileName, true, Encoding.UTF8))
            {
                logWriter.WriteLine(String.Format("{0}  {1}  {2}",
                    level, DateTime.UtcNow.ToString(), information));
            }
        }

        public void WriteLog(LogLevel level, Exception exception)
        {
            if (!Directory.Exists(LogPath))
            {
                Directory.CreateDirectory(LogPath);
            }
            using (var logWriter = new StreamWriter(FileName, true, Encoding.UTF8))
            {
                logWriter.WriteLine(String.Format("{0}  {1}\nException Messsage: {2}",
                    level, DateTime.UtcNow.ToString(), exception.ToString()));
            }
        }
    }
}
