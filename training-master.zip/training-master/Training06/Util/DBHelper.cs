﻿namespace Training06.Util
{
    #region using directives

    using System;
    using System.Data.SqlClient;
    using EnumClass;
    using System.Data;
    using CompanyItem;
    #endregion using directives

    public sealed class DBHelper
    {
        private static readonly DBHelper helper = new DBHelper();
        private LogUtil logHelper;
        private SqlConnectionStringBuilder sqlBuilder;
        private SqlConnection connection;

        private DBHelper()
        {
            this.logHelper = LogUtil.GetLogUtil();
            this.sqlBuilder = new SqlConnectionStringBuilder();
            this.connection = new SqlConnection();
            this.sqlBuilder.DataSource = @"CNDL20140164T1\CSL";
            this.sqlBuilder.InitialCatalog = "Company";
            this.sqlBuilder.IntegratedSecurity = false;
            this.sqlBuilder.UserID = "sa";
            this.sqlBuilder.Password = "1qaz2wsxE";
        }

        public static DBHelper GetDBHelper()
        {
            return helper;
        }

        #region Basic Mehtod 

        public SqlConnection GetConnection()
        {
            this.connection.ConnectionString = sqlBuilder.ToString();
            this.connection.Open();
            return this.connection;
        }

        public DataTable GetEmployeeInfo(String sql)
        {
            using (this.GetConnection())
            {
                try
                {
                    var comm = new SqlCommand(sql, this.connection);
                    var adapter = new SqlDataAdapter(comm);
                    var table = new DataTable();
                    adapter.Fill(table);
                    return table;
                }
                catch (Exception exception)
                {
                    this.logHelper.WriteLog(LogLevel.WARNING, exception);
                    return null;
                }
            }
        }

        public DataTable GetDevelopmentInfo(String sql)
        {
            using (this.GetConnection())
            {
                try
                {
                    var comm = new SqlCommand(sql, this.connection);
                    var adapter = new SqlDataAdapter(comm);
                    var table = new DataTable();
                    adapter.Fill(table);
                    return table;
                }
                catch (Exception exception)
                {
                    this.logHelper.WriteLog(LogLevel.WARNING, exception);
                    return null;
                }
            }
        }

        public Int32 InsertEmployeeInfo(Employee employee, String sql)
        {
            using (this.GetConnection())
            {
                try
                {
                    var comm = new SqlCommand(sql, this.connection);
                    comm.Parameters.Add(new SqlParameter("@name", employee.Name));
                    comm.Parameters.Add(new SqlParameter("@gender", employee.Gender));
                    comm.Parameters.Add(new SqlParameter("@devName", employee.DevName));
                    comm.Parameters.Add(new SqlParameter("@job", employee.Job.ToString()));
                    return comm.ExecuteNonQuery();
                }
                catch (Exception exception)
                {
                    this.logHelper.WriteLog(LogLevel.WARNING, exception);
                    return -1;
                }
            }
        }

        public Int32 DeleteEmployeeInfo(Int32 id, String sql)
        {
            using (this.GetConnection())
            {
                try
                {
                    var comm = new SqlCommand(sql, this.connection);
                    comm.Parameters.Add(new SqlParameter("@id", id));
                    return comm.ExecuteNonQuery();
                }
                catch (Exception exception)
                {
                    this.logHelper.WriteLog(LogLevel.WARNING, exception);
                    return -1;
                }
            }
        }

        public Int32 TransferEmployeeInfo(Int32 id, String devName, String sql)
        {
            using (this.GetConnection())
            {
                try
                {
                    var comm = new SqlCommand(sql, this.connection);
                    comm.Parameters.Add(new SqlParameter("@devName", devName));
                    comm.Parameters.Add(new SqlParameter("@id", id));
                    return comm.ExecuteNonQuery();
                }
                catch (Exception exception)
                {
                    this.logHelper.WriteLog(LogLevel.WARNING, exception);
                    return -1;
                }
            }
        }

        public Int32 UpdateJobInfo(Int32 id, DevJob job, String sql)
        {
            using (this.GetConnection())
            {
                try
                {
                    var comm = new SqlCommand(sql, this.connection);
                    comm.Parameters.Add(new SqlParameter("@updateEid", SqlDbType.Int));
                    comm.Parameters.Add(new SqlParameter("@updateJob", SqlDbType.VarChar));
                    comm.Parameters["@updateEid"].Direction = ParameterDirection.Input;
                    comm.Parameters["@updateJob"].Direction = ParameterDirection.Input;
                    comm.Parameters["@updateEid"].Value = id;
                    comm.Parameters["@updateJob"].Value = job.ToString();
                    comm.CommandType = CommandType.StoredProcedure;
                    return comm.ExecuteNonQuery();
                }
                catch (Exception exception)
                {
                    this.logHelper.WriteLog(LogLevel.WARNING, exception);
                    return -1;
                }
            }
        }

        public Int32 InsertDevelopmentInfo(Development development, String sql)
        {
            using (this.GetConnection())
            {
                try
                {
                    var comm = new SqlCommand(sql, this.connection);
                    comm.Parameters.Add(new SqlParameter("@name", development.Name));
                    comm.Parameters.Add(new SqlParameter("@brief", development.Brief));
                    return comm.ExecuteNonQuery();
                }
                catch (Exception exception)
                {
                    this.logHelper.WriteLog(LogLevel.WARNING, exception);
                    return -1;
                }
            }
        }

        public Int32 SetLeaderInfo(String devName, Int32 id, String sql)
        {
            using (this.GetConnection())
            {
                try
                {
                    var comm = new SqlCommand(sql, this.connection);
                    comm.Parameters.Add(new SqlParameter("@id", SqlDbType.Int));
                    comm.Parameters.Add(new SqlParameter("@devName", SqlDbType.VarChar));
                    comm.Parameters["@id"].Direction = ParameterDirection.Input;
                    comm.Parameters["@devName"].Direction = ParameterDirection.Input;
                    comm.Parameters["@id"].Value = id;
                    comm.Parameters["@devName"].Value = devName;
                    //SqlParameter result = new SqlParameter("@return",SqlDbType.Int);
                    //comm.Parameters.Add(result);
                    //comm.Parameters["@return"].Direction = ParameterDirection.ReturnValue;
                    comm.CommandType = CommandType.StoredProcedure;
                    return comm.ExecuteNonQuery();
                    //return (Int32)result.Value;
                }
                catch (Exception exception)
                {
                    this.logHelper.WriteLog(LogLevel.WARNING, exception);
                    return -1;
                }
            }
        }
        
        public Int32 DeleteDevelopmentInfo(String name, String sql)
        {
            using (this.GetConnection())
            {
                try
                {
                    var comm = new SqlCommand(sql, this.connection);
                    comm.Parameters.Add(new SqlParameter("@name", name));
                    return comm.ExecuteNonQuery();
                }
                catch (Exception exception)
                {
                    this.logHelper.WriteLog(LogLevel.WARNING, exception);
                    return -1;
                }
            }
        }

        public Int32 InsertManagementInfo(Int32 id, String devName, String sql)
        {
            using (this.GetConnection())
            {
                try
                {
                    var comm = new SqlCommand(sql, this.connection);
                    SqlParameter result = new SqlParameter("@return", SqlDbType.Int);
                    comm.Parameters.Add(result);
                    comm.Parameters.Add(new SqlParameter("@eId", SqlDbType.Int));
                    comm.Parameters.Add(new SqlParameter("@devName", SqlDbType.VarChar));
                    comm.Parameters["@eId"].Direction = ParameterDirection.Input;
                    comm.Parameters["@devName"].Direction = ParameterDirection.Input;
                    comm.Parameters["@return"].Direction = ParameterDirection.ReturnValue;
                    comm.Parameters["@eId"].Value = id;
                    comm.Parameters["@devname"].Value = devName;
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.ExecuteNonQuery();
                    return (Int32)result.Value;
                }
                catch (Exception exception)
                {
                    this.logHelper.WriteLog(LogLevel.WARNING, exception);
                    return -1;
                }
            }
        }

        public Int32 CheckIdInManagementInfo(Int32 id, String sql)
        {
            using (this.GetConnection())
            {
                try
                {
                    var comm = new SqlCommand(sql, this.connection);
                    comm.Parameters.Add(new SqlParameter("@eId", id));
                    comm.CommandType = CommandType.StoredProcedure;
                    return comm.ExecuteNonQuery();
                }
                catch (Exception exception)
                {
                    this.logHelper.WriteLog(LogLevel.WARNING, exception);
                    return -1;
                }
            }
        }

        public Int32 CheckDevInManagementInfo(String devName,String sql)
        {
            using (this.GetConnection())
            {
                try
                {
                    var comm = new SqlCommand(sql, this.connection);
                    comm.Parameters.Add(new SqlParameter("@devName",devName));
                    comm.CommandType = CommandType.StoredProcedure;
                    return comm.ExecuteNonQuery();
                }
                catch (Exception exception)
                {
                    this.logHelper.WriteLog(LogLevel.WARNING, exception);
                    return -1;
                }
            }
        }

        public DataTable SelectAllDevelopmentInfo(String sql)
        {
            using (this.GetConnection())
            {
                try
                {
                    var comm = new SqlCommand(sql, this.connection);
                    SqlDataAdapter adapter = new SqlDataAdapter(comm);
                    DataTable table = new DataTable();
                    adapter.Fill(table);
                    return table;
                }
                catch (Exception exception)
                {
                    this.logHelper.WriteLog(LogLevel.WARNING, exception);
                    return null;
                }
            }
        }

        public DataTable SelectEmployeeInfo(Int32 id, String sql)
        {
            using (this.GetConnection())
            {
                try
                {
                    var comm = new SqlCommand(sql, this.connection);
                    comm.Parameters.Add(new SqlParameter("@selectEid", SqlDbType.Int));
                    comm.Parameters["@selectEid"].Direction = ParameterDirection.Input;
                    comm.Parameters["@selectEid"].Value = id;
                    comm.CommandType = CommandType.StoredProcedure;
                    var adapter = new SqlDataAdapter(comm);
                    var table = new DataTable();
                    adapter.Fill(table);
                    return table;
                }
                catch (Exception exception)
                {
                    this.logHelper.WriteLog(LogLevel.WARNING, exception);
                    return null;
                }
            }
        }

        public DataTable SelectAllEmployeeInfo(String sql)
        {
            using (this.GetConnection())
            {
                try
                {
                    var comm = new SqlCommand(sql, this.connection);
                    var adapter = new SqlDataAdapter(comm);
                    var table = new DataTable();
                    adapter.Fill(table);
                    return table;
                }
                catch (Exception exception)
                {
                    this.logHelper.WriteLog(LogLevel.WARNING, exception);
                    return null;
                }
            }
        }

        public DataTable SelectDevAllEmployeeInfo(String devName, String sql)
        {
            using (this.GetConnection())
            {
                try
                {
                    var comm = new SqlCommand(sql, this.connection);
                    comm.Parameters.Add(new SqlParameter("@selectDev", SqlDbType.VarChar));
                    comm.Parameters["@selectDev"].Direction = ParameterDirection.Input;
                    comm.Parameters["@selectDev"].Value = devName;
                    comm.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter adapter = new SqlDataAdapter(comm);
                    DataTable table = new DataTable();
                    adapter.Fill(table);
                    return table;
                }
                catch (Exception exception)
                {
                    this.logHelper.WriteLog(LogLevel.WARNING, exception);
                    return null;
                }
            }
        }

        public DataTable SelectManagementInfo(Int32 id, String sql)
        {
            using (this.GetConnection())
            {
                try
                {
                    var comm = new SqlCommand(sql, this.connection);
                    comm.Parameters.Add(new SqlParameter("@selectEid", SqlDbType.Int));
                    comm.Parameters["@selectEid"].Direction = ParameterDirection.Input;
                    comm.Parameters["@selectEid"].Value = id;
                    comm.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter adapter = new SqlDataAdapter(comm);
                    DataTable table = new DataTable();
                    adapter.Fill(table);
                    return table;
                }
                catch (Exception exception)
                {
                    this.logHelper.WriteLog(LogLevel.WARNING, exception);
                    return null;
                }
            }
        }

        public DataTable EmployeeLeaderInfo(Int32 id, String sql)
        {
            using (this.GetConnection())
            {
                try
                {
                    var comm = new SqlCommand(sql, this.connection);
                    comm.Parameters.Add(new SqlParameter("@id", SqlDbType.Int));
                    comm.Parameters["@id"].Direction = ParameterDirection.Input;
                    comm.Parameters["@id"].Value = id;
                    comm.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter adapter = new SqlDataAdapter(comm);
                    DataTable table = new DataTable();
                    adapter.Fill(table);
                    return table;
                }
                catch (Exception exception)
                {
                    this.logHelper.WriteLog(LogLevel.WARNING, exception);
                    return null;
                }
            }
        }

        #endregion Basic Method
    }
}
