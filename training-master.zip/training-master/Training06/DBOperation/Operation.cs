namespace Training06.DBOperation
{
    #region using directives

    using CompanyItem;
    using EnumClass;
    using System;
    using System.Collections.Generic;
    using System.Data;
    using Util;

    #endregion using directives

    public class Operation
    {
        #region Private Field

        private String sql = "";
        private DBHelper helper = DBHelper.GetDBHelper();
        private Boolean isEnd;
        private LogUtil logHelper;

        #endregion Private Field

        public List<Employee> employeeList;
        public List<Development> developmentList;
        public List<String> operation;


        #region Basic Mehtod

        public Operation()
        {
            this.logHelper = LogUtil.GetLogUtil();
            this.employeeList = new List<Employee>();
            this.developmentList = new List<Development>();
            this.operation = new List<String>();
            this.operation.Add("0.退出");
            this.operation.Add("1.新增员工");
            this.operation.Add("2.删除员工");
            this.operation.Add("3.员工部门调转");
            this.operation.Add("4.员工职务调动");
            this.operation.Add("5.添加部门");
            this.operation.Add("6.设置部门部长");
            this.operation.Add("7.删除部门");
            this.operation.Add("8.添加员工管辖部门");
            this.operation.Add("9.查询所有部门");
            this.operation.Add("10.通过员工编号查询员工信息");
            this.operation.Add("11.查询所有员工信息");
            this.operation.Add("12.查询部门下的所有员工");
            this.operation.Add("13.查询员工所管辖的部门");
            this.operation.Add("14.查询员工的部长");
        }

        public void GetData()
        {
            this.employeeList.Clear();
            this.developmentList.Clear();
            this.sql = "select EId,Name,Gender,DevName,Job from Employee";
            var emlpoyeeTable = helper.GetEmployeeInfo(this.sql);
            this.sql = "select Name,Brief from Development";
            var developmentTable = helper.GetEmployeeInfo(this.sql);
            try
            {
                foreach (DataRow row in emlpoyeeTable.Rows)
                {
                    var employee = new Employee();
                    employee.EId = (Int32)row["EId"];
                    employee.Name = row["Name"].ToString();
                    employee.Gender = (Int32)row["Gender"];
                    employee.DevName = row["DevName"].ToString();
                    if (row["Job"].ToString() == DevJob.expert.ToString())
                    {
                        employee.Job = DevJob.expert;
                    }
                    else if (row["Job"].ToString() == DevJob.leader.ToString())
                    {
                        employee.Job = DevJob.leader;
                    }
                    employeeList.Add(employee);
                }
                foreach (DataRow row in developmentTable.Rows)
                {
                    var development = new Development();
                    development.Name = row["Name"].ToString();
                    development.Brief = row["Brief"].ToString();
                    this.developmentList.Add(development);
                }
                this.logHelper.WriteLog(LogLevel.INFO, "Get employee and development information.");
            }
            catch(Exception exception)
            {
                this.logHelper.WriteLog(LogLevel.WARNING, exception);
            }
            
        }

        public Boolean IsEnd()
        {
            return !this.isEnd;
        }

        public Int32 InsertEmployee(Employee employee)
        {
            this.logHelper.WriteLog(LogLevel.INFO, "InsertEmployee.");
            this.sql = "insert into Employee(Name,Gender,DevName,Job) values (@name, @gender, @devName, @job)";
            return helper.InsertEmployeeInfo(employee, this.sql);
        }

        public Int32 DeleteEmployee(Int32 id)
        {
            this.logHelper.WriteLog(LogLevel.INFO, "DeleteEmployee.");
            this.sql = "delete from Employee where EId = @id";
            return helper.DeleteEmployeeInfo(id, this.sql);
        }

        public Int32 TransferEmployee(Int32 id, String devName)
        {
            this.logHelper.WriteLog(LogLevel.INFO, "TransferEmployee.");
            this.sql = "update Employee set DevName = @devName where EId = @id";
            return helper.TransferEmployeeInfo(id, devName, sql);
        }

        public Int32 UpdateJob(Int32 id, DevJob job)
        {
            this.logHelper.WriteLog(LogLevel.INFO, "UpdateJob.");
            this.sql = "UpdateJob";
            return helper.UpdateJobInfo(id, job, this.sql);
        }

        public Int32 InsertDevelopment(Development development)
        {
            this.logHelper.WriteLog(LogLevel.INFO, "InsertDevelopment.");
            this.sql = "insert into Development(Name,Brief) values (@name,@brief)";
            return helper.InsertDevelopmentInfo(development, this.sql);
        }

        public Int32 SetLeader(String devName, Int32 id)
        {
            this.logHelper.WriteLog(LogLevel.INFO, "SetLeader.");
            this.sql = "SetLeader";
            return helper.SetLeaderInfo(devName, id, sql);
        }

        public Int32 DeleteDevelopment(String name)
        {
            this.logHelper.WriteLog(LogLevel.INFO, "DeleteDevelopment.");
            this.sql = "delete from Development where Name = @name";
            return helper.DeleteDevelopmentInfo(name, this.sql);
        }

        public Int32 InsertManagement(Int32 id, String devName)
        {
            this.logHelper.WriteLog(LogLevel.INFO, "InsertManagement.");
            this.sql = "InsertManagement";
            return helper.InsertManagementInfo(id, devName, this.sql);
        }

        public Int32 CheckIdInManagement(Int32 id)
        {
            this.logHelper.WriteLog(LogLevel.INFO, "CheckIdInManagement.");
            this.sql = "select EId from Management where EId = @eId";
            return helper.CheckIdInManagementInfo(id, this.sql);
        }

        public Int32 CheckDevInManagement(String devName)
        {
            this.logHelper.WriteLog(LogLevel.INFO, "CheckDevInManagement.");
            this.sql = "select EId from Management where EId = @devName";
            return helper.CheckDevInManagementInfo(devName, this.sql);
        }

        public DataTable SelectAllDevelopment()
        {
            this.logHelper.WriteLog(LogLevel.INFO, "SelectAllDevelopment.");
            this.sql = "execute SelectAllDevInfo";
            return helper.SelectAllDevelopmentInfo(this.sql);
        }

        public DataTable SelectEmployee(Int32 id)
        {
            this.logHelper.WriteLog(LogLevel.INFO, "SelectEmployee.");
            this.sql = "SelectEmployeeInfo";
            return helper.SelectEmployeeInfo(id, this.sql);
        }

        public DataTable SelectAllEmployee()
        {
            this.logHelper.WriteLog(LogLevel.INFO, "SelectAllEmployee.");
            this.sql = "execute SelectAllEmployeeInfo";
            return helper.SelectAllEmployeeInfo(this.sql);
        }

        public DataTable SelectDevAllEmployee(String devName)
        {
            this.logHelper.WriteLog(LogLevel.INFO, "SelectDevAllEmployee.");
            this.sql = "SelectDevAllEmployee";
            return helper.SelectDevAllEmployeeInfo(devName, this.sql);
        }

        public DataTable SelectManagement(Int32 id)
        {
            this.logHelper.WriteLog(LogLevel.INFO, "SelectManagement.");
            this.sql = "SelectManagement";
            return helper.SelectManagementInfo(id, this.sql);
        }

        public DataTable EmployeeLeader(Int32 id)
        {
            this.logHelper.WriteLog(LogLevel.INFO, "EmployeeLeader.");
            this.sql = "EmployeeLeader";
            return helper.EmployeeLeaderInfo(id, this.sql);
        }

        #endregion Basic Method
    }
}
