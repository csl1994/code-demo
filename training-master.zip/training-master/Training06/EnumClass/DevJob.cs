﻿namespace Training06.EnumClass
{
    public enum DevJob
    {
        member,
        leader,
        expert
    }
}
