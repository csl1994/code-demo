﻿namespace Training06
{
    #region using directives

    using CompanyItem;
    using DBOperation;
    using EnumClass;
    using System;
    using System.Data;
    using System.IO;
    using Util;

    #endregion using directives

    public class Program
    {
        private static Operation myTest = new Operation();
        private static Boolean isEnd = default(Boolean);
        private static LogUtil logHelper = LogUtil.GetLogUtil();

        public static void Main()
        {
            try
            {
                InputLogPath();
                myTest.GetData();
                var num = -1;
                var result = 0;
                Console.WriteLine("Press enter test program.");
                Console.ReadLine();
                while (!isEnd)
                {
                    result = -1;
                    foreach (var item in myTest.operation)
                    {
                        Console.WriteLine(item);
                    }
                    do
                    {
                        Console.WriteLine("Input operation number.");
                        try
                        {
                            num = Convert.ToInt32(Console.ReadLine());
                        }
                        catch
                        {
                            Console.WriteLine("Input context error.");
                        }
                    }
                    while (num < 0 || num > 14);
                    result = SelectOperation(num);
                    if (result > 0)
                    {
                        Console.WriteLine("Operation success.");
                    }
                    else if (result == -2)
                    {
                        Console.WriteLine("Data is not adapt.");
                    }
                    else if(result == -1)
                    {
                        Console.WriteLine("Operation defeat.");
                    }
                    Console.WriteLine("Press enter go on.");
                    Console.ReadLine();
                }

            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
                Console.ReadLine();
            }
        }

        public static void InputLogPath()
        {
            var path = "";
            var isInput = "";
            do
            {
                Console.Write("Input log dirctory?(y/n):");
                isInput = Console.ReadLine().Trim().ToLower();

            }
            while (isInput != "y" && isInput != "n");
            if (isInput == "y")
            {
                try
                {
                    do
                    {
                        Console.Write("Input log dirctory:");
                        path = Console.ReadLine().Trim();
                    }
                    while (!Directory.Exists(path));
                    logHelper.LogPath = path;
                }
                catch(Exception exception)
                {
                    Console.WriteLine("errpr:{0}",exception.ToString());
                }
                
            }
        }

        public static Int32 SelectOperation(Int32 num)
        {
            var result = 0;
            var isContinue = "y";
            var id = 0;
            var job = DevJob.member;
            var devName = String.Empty;
            var jobNum = String.Empty;
            var resultTable = new DataTable();
            var employee = new Employee();
            var development = new Development();
            switch (num)
            {
                case 0:
                    isEnd = myTest.IsEnd();
                    break;
                case 1:
                    OneInput(employee);
                    Console.WriteLine("Press enter begin.");
                    Console.ReadLine();
                    result = myTest.InsertEmployee(employee);
                    myTest.GetData();
                    break;
                case 2:
                    id = InputId();
                    Console.WriteLine("Press enter begin.");
                    Console.ReadLine();
                    result = myTest.DeleteEmployee(id);
                    myTest.GetData();
                    break;
                case 3:
                    id = InputId();
                    devName = InputDevName();
                    Console.WriteLine("Press enter begin.");
                    Console.ReadLine();
                    result = myTest.TransferEmployee(id, devName);
                    myTest.GetData();
                    break;
                case 4:
                    FourInput(ref id, ref jobNum);
                    if (jobNum == "2")
                    {
                        job = DevJob.leader;
                    }
                    else if (jobNum == "3")
                    {
                        job = DevJob.expert;
                    }
                    Console.WriteLine("Press enter begin.");
                    Console.ReadLine();
                    result = myTest.UpdateJob(id, job);
                    myTest.GetData();
                    break;
                case 5:
                    FiveInput(development);
                    Console.WriteLine("Press enter begin.");
                    Console.ReadLine();
                    result = myTest.InsertDevelopment(development);
                    myTest.GetData();
                    break;
                case 6:
                    devName = InputDevName();
                    id = InputId();
                    Console.WriteLine("Press enter begin.");
                    Console.ReadLine();
                    result = myTest.SetLeader(devName, id);
                    myTest.GetData();
                    break;
                case 7:
                    devName = InputDevName();
                    Console.WriteLine("Press enter begin.");
                    Console.ReadLine();
                    result = myTest.DeleteDevelopment(devName);
                    myTest.GetData();
                    break;
                case 8:
                    id = InputId();
                    devName = InputDevName();
                    Console.WriteLine("Press enter begin.");
                    Console.ReadLine();
                    if (myTest.CheckDevInManagement(devName) > 0 || myTest.CheckIdInManagement(id) > 0)
                    {
                        do
                        {
                            Console.Write("Some information already existed.continue?(y/n):");
                            isContinue = Console.ReadLine().Trim().ToLower();
                        }
                        while (isContinue != "y" && isContinue != "n");
                    }
                    if (isContinue == "y")
                    {
                        result = myTest.InsertManagement(id, devName);
                        myTest.GetData();
                    }
                    else
                    {
                        result = 1;
                    }
                    break;
                case 9:
                    ReadTable(myTest.SelectAllDevelopment());
                    result = 1;
                    break;
                case 10:
                    id = InputId();
                    ReadTable(myTest.SelectEmployee(id));
                    result = 1;
                    break;
                case 11:
                    ReadTable(myTest.SelectAllEmployee());
                    result = 1;
                    break;
                case 12:
                    devName = InputDevName();
                    ReadTable(myTest.SelectDevAllEmployee(devName));
                    result = 1;
                    break;
                case 13:
                    id = InputId();
                    ReadTable(myTest.SelectManagement(id));
                    result = 1;
                    break;
                case 14:
                    id = InputId();
                    ReadTable(myTest.EmployeeLeader(id));
                    result = 1;
                    break;
                default:
                    break;
            }
            return result;
        }

        public static void ReadTable(DataTable table)
        {
            if (table.Rows.Count > 0)
            {
                foreach (var title in table.Columns)
                {
                    Console.Write("{0}\t", title);
                }
                Console.WriteLine();
                foreach (DataRow row in table.Rows)
                {
                    foreach (DataColumn column in table.Columns)
                    {
                        if (column.ToString().Trim().ToLower() == "gender")
                        {
                            Console.Write("{0}\t", row[column].ToString().Trim() == "1" ? "Man" : "Woman");
                        }
                        else
                        {
                            Console.Write("{0}\t", row[column]);
                        }
                    }
                    Console.WriteLine();
                }
            }
            else
            {
                Console.WriteLine("No result.");
            }
        }

        public static Int32 InputId()
        {
            var id = 0;
            do
            {
                try
                {
                    var isLook = String.Empty;
                    do
                    {
                        Console.Write("Look at all employee?(y/n):");
                        isLook = Console.ReadLine().Trim().ToLower();
                    }
                    while (isLook != "y" && isLook != "n");
                    if (isLook == "y")
                    {
                        if(ShowEmployee() == 0)
                        {
                            break;
                        }
                    }
                    Console.Write("Input employee id:");
                    id = Convert.ToInt32(Console.ReadLine());
                }
                catch
                {
                    Console.WriteLine("Input context error.");
                }
            }
            while (id <= 0);
            return id;
        }

        public static String InputDevName()
        {
            var devName = String.Empty;
            do
            {
                var isLook = String.Empty;
                do
                {
                    Console.Write("Look at all development?(y/n):");
                    isLook = Console.ReadLine().Trim().ToLower();
                }
                while (isLook != "y" && isLook != "n");
                if (isLook == "y")
                {
                    if(ShowDevelopment() == 0)
                    {
                        break;
                    }
                }
                Console.Write("Input employee development:");
                devName = Console.ReadLine().Trim();
            }
            while (String.IsNullOrWhiteSpace(devName));
            return devName;
        }

        public static Int32 ShowDevelopment()
        {
            var result = 1;
            if (myTest.developmentList.Count == 0)
            {
                Console.WriteLine("No development.");
                result = 0;
            }
            else
            {
                foreach (var item in myTest.developmentList)
                {
                    Console.WriteLine(item.ToString());
                }
            }
            return result;
        }

        public static Int32 ShowEmployee()
        {
            var result = 1;
            if(myTest.employeeList.Count == 0)
            {
                Console.WriteLine("No employee.");
                result = 0;
            }
            else
            {
                foreach (var item in myTest.employeeList)
                {
                    Console.WriteLine(item.ToString());
                }
            }
            return result;
        }

        public static void OneInput(Employee employee)
        {
            var genderStr = String.Empty;
            var jobNum = String.Empty;
            employee.Gender = 0;
            do
            {
                Console.Write("Input employee name:");
                employee.Name = Console.ReadLine().Trim();
            }
            while (String.IsNullOrWhiteSpace(employee.Name) || employee.Name.Length > 20);
            do
            {
                Console.Write("Input employee gender(M=1,W=0):");
                genderStr = Console.ReadLine().Trim();
            }
            while (genderStr != "1" && genderStr != "0");
            if (genderStr == "1")
            {
                employee.Gender = 1;
            }
            employee.DevName = InputDevName();
            while (String.IsNullOrWhiteSpace(employee.DevName) || employee.DevName.Length > 20) ;
            do
            {
                Console.Write("Input job number(1.{0}2.{1}3.{2}):", DevJob.member, DevJob.leader, DevJob.expert);
                jobNum = Console.ReadLine().Trim();
            }
            while (jobNum != "1" && jobNum != "2" && jobNum != "3");
            if (jobNum == "2")
            {
                employee.Job = DevJob.leader;
            }
            else if (jobNum == "3")
            {
                employee.Job = DevJob.expert;
            }
        }

        public static void FourInput(ref Int32 id, ref String jobNum)
        {
            id = InputId();
            do
            {
                Console.Write("Input job number(1.{0}2.{1}3.{2}):", DevJob.member, DevJob.leader, DevJob.expert);
                jobNum = Console.ReadLine().Trim();
            }
            while (jobNum != "1" && jobNum != "2" && jobNum != "3");
        }

        public static void FiveInput(Development development)
        {
            do
            {
                Console.Write("Input development name:");
                development.Name = Console.ReadLine().Trim();
            }
            while (String.IsNullOrWhiteSpace(development.Name) || development.Name.Length > 20);
            do
            {
                Console.Write("Input development brief:");
                development.Brief = Console.ReadLine().Trim();
            }
            while (String.IsNullOrWhiteSpace(development.Brief) || development.Brief.Length > 255);
        }
    }
}
