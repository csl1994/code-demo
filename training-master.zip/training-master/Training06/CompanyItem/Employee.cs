﻿namespace Training06.CompanyItem
{
    #region using directives

    using EnumClass;
    using System;

    #endregion using directives
    public class Employee
    {

        public Int32 EId { get; set; }
        public String Name { get; set; }
        public Int32 Gender { get; set; }
        public String DevName { get; set; }
        public DevJob Job { get; set; }

        public Employee()
        {
            this.Job = DevJob.member;
        }

        public override String ToString()
        {
            return String.Format("EId:{0} Name:{1} Gender:{2} DevName:{3} Job:{4} ",
                   this.EId, this.Name, (this.Gender == 1 ? "Man" : "Woman"), this.DevName, this.Job);

        }
    }
}
