﻿namespace Training06.CompanyItem
{
    #region using directives

    using System;

    #endregion using directives
    public class Development
    {
        public String Name { get; set; }

        public String Brief { get; set; }

        public Development()
        {
            this.Brief = "A development.";
        }

        public override String ToString()
        {
            return String.Format("Name:{0} Brief:{1}", this.Name, this.Brief);
        }
    }
}
