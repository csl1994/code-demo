﻿namespace Training01
{
    #region
    using System;
    using System.Collections.Generic;
    #endregion

    public class Test
    {
        private List<String> arrayNum = new List<String>();
        public Int32 GetLength()
        {
            return this.arrayNum.Count;
        }
        public void InputNum()
        {
            Console.Write("输入数字:");
            try
            {
                Int64 inputNum = Convert.ToInt32(Console.ReadLine());
                arrayNum.Add(inputNum.ToString());
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public void Input()
        {
            Console.WriteLine("任何输入以enter结束");
            while (true)
            {
                Console.WriteLine("是否添加数字(Y/N)");
                String inputIs = Console.ReadLine();
                if (inputIs.Equals("Y") || inputIs.Equals("y"))
                {
                    InputNum();
                }
                else if (inputIs.Equals("N") || inputIs.Equals("n"))
                {
                    Console.WriteLine("结束输入");
                    break;
                }
                else {
                    Console.Write("输入错误,");
                }
            }
        }
        public void Merge(Char[] items, Int32 low, Int32 mid, Int32 high)
        {
            Char[] temp = new Char[high - low + 1];
            Int32 i = low;
            Int32 j = mid + 1;
            Int32 k = 0;

            while (i <= mid && j <= high)
            {
                if (items[i].CompareTo(items[j]) < 0)
                {
                    temp[k++] = items[i++];
                }
                else {
                    temp[k++] = items[j++];
                }
            }

            while (i <= mid)
            {
                temp[k++] = items[i++];
            }

            while (j <= high)
            {
                temp[k++] = items[j++];
            }

            for (Int32 l = 0; l < temp.Length; l++)
            {
                items[l + low] = temp[l];
            }

        }
        public void MergeSort(Char[] items)
        {

            Int32 size = 1;
            Int32 low = 0;
            Int32 mid = 0;
            Int32 high = 0;

            while (size < items.Length)
            {
                low = 0;
                while (low + size < items.Length)
                {
                    mid = low + size - 1;
                    high = mid + size;
                    if (high >= items.Length)
                    {
                        high = items.Length - 1;
                    }
                    Merge(items, low, mid, high);
                    low = high + 1;
                }
                size *= 2;
            }
        }
        public void Sort()
        {
            for (Int32 k = 0; k < arrayNum.Count; k++)
            {
                if (arrayNum[k].Trim().StartsWith("-"))
                {
                    Char[] items = arrayNum[k].TrimStart('-').ToCharArray();
                    Console.WriteLine("ss");
                    MergeSort(items);
                    arrayNum[k] = "-" + new String(items);
                }
                else
                {
                    Char[] items = arrayNum[k].ToCharArray();
                    Console.WriteLine("aa");
                    MergeSort(items);
                    arrayNum[k] = new String(items);
                }
            }

        }
        public String FindMax()
        {
            Int32 max = 0;
            for (Int32 i = 1; i < arrayNum.Count; i++)
            {
                if(arrayNum[i].StartsWith("-") && arrayNum[max].StartsWith("-"))
                {
                    if (arrayNum[i].TrimStart('0','-').Length < arrayNum[max].TrimStart('0','-').Length)
                    {
                        max = i;
                    }
                    else if (arrayNum[i].TrimStart('0','-').Length == arrayNum[max].TrimStart('0','-').Length
                            && arrayNum[i].TrimStart('0','-').CompareTo(arrayNum[max].TrimStart('0','-')) > 0)
                    {

                        max = i;
                    }
                }
                else if (!arrayNum[i].StartsWith("-") && arrayNum[max].StartsWith("-"))
                {
                    max = i;
                }
                else if (!arrayNum[i].StartsWith("-") && !arrayNum[max].StartsWith("-"))
                {
                    if (arrayNum[i].TrimStart('0').Length > arrayNum[max].TrimStart('0').Length)
                    {
                        max = i;
                    }
                    else if (arrayNum[i].TrimStart('0').Length == arrayNum[max].TrimStart('0').Length
                            && arrayNum[i].TrimStart('0').CompareTo(arrayNum[max].TrimStart('0')) > 0)
                    {

                        max = i;
                    }
                }
            }

            return arrayNum[max];
        }
        public void ShowArray()
        {
            Console.WriteLine("~~~~~~~~~~~~~~~~~~~~");
            foreach (var item in arrayNum)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine("~~~~~~~~~~~~~~~~~~~~");
        }
        static void Main(String [] args)
        {
            try
            {
                Console.WriteLine("程序测试\n");
                Test test = new Test();

                test.Input();
                if (test.GetLength() > 0)
                {
                    test.ShowArray();
                    test.Sort();
                    Console.WriteLine("\n最大的数{0}", test.FindMax());
                    test.ShowArray();
                }
                else
                {
                    Console.WriteLine("\n没有任何数字");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            finally
            {
                Console.ReadKey();
                Console.WriteLine("\n测试结束");
            }

        }
    }

}