﻿namespace Contracts
{
    #region using directives

    using System;
    using System.ServiceModel;

    #endregion using directives

    [ServiceContract(Namespace = "training", CallbackContract = typeof(ICalculateCallBack))]
    public interface ICalculate
    {
        [OperationContract(IsOneWay = true)]
        void Add(Double num1, Double num2);

        [OperationContract(IsOneWay = true)]
        void Sub(Double num1, Double num2);

        [OperationContract(IsOneWay = true)]
        void Mul(Double num1, Double num2);

        [OperationContract(IsOneWay = true)]
        void Div(Double num1, Double num2);
    }
}
