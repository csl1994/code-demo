﻿namespace Clients
{
    #region using directives

    using Contracts;
    using System;
    using System.ServiceModel;
    using System.Threading;

    #endregion using directives

    public class Program
    {
        public static void Main()
        {
            try
            {
                Console.WriteLine("Press enter begin;");
                Console.ReadLine();
                var instance = new InstanceContext(new CalculateCallBackImpl());
                using (DuplexChannelFactory<ICalculate> factory = new DuplexChannelFactory<ICalculate>(instance, new NetTcpBinding(),
                    new EndpointAddress("net.tcp://LocalHost:8080")))
                {
                    var proxy = factory.CreateChannel();
                    var isContinue = "y";
                    do
                    {
                        Console.Write("Continue?(y/n):");
                        isContinue = Console.ReadLine().Trim().ToLower();
                    }
                    while (isContinue != "y" && isContinue != "n");
                    while (isContinue == "y")
                    {
                        var num1 = InputNum();
                        var operation = InputOperation();
                        var num2 = InputNum();
                        switch (operation)
                        {
                            case "+":
                                proxy.Add(num1, num2);
                                break;
                            case "-":
                                proxy.Sub(num1, num2);
                                break;
                            case "*":
                                proxy.Mul(num1, num2);
                                break;
                            case "/":
                                proxy.Div(num1, num2);
                                break;
                            default:
                                break;
                        }
                        Thread.Sleep(2000);
                        do
                        {
                            Console.Write("Continue?(y/n):");
                            isContinue = Console.ReadLine().Trim().ToLower();
                        }
                        while (isContinue != "y" && isContinue != "n");
                    }
                    Console.WriteLine("Program will esc.");

                }
            }
            catch(Exception e)
            {
                Console.WriteLine(e.ToString());
            }
            finally
            {
                Console.ReadLine();
            }
        }

        public static Double InputNum()
        {
            var result = 0.0;
            do
            {
                Console.Write("Input operation num:");
            }
            while (!Double.TryParse(Console.ReadLine(), out result));
            return result;
        }

        public static String InputOperation()
        {
            var operation = "";
            do
            {
                Console.Write("Input operation(+,-,*,/):");
                operation = Console.ReadLine().Trim();
            }
            while (operation != "+" && operation != "-" && operation != "*" && operation != "/");
            return operation;
        }
    }
}
