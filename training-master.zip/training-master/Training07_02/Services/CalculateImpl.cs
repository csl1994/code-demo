﻿namespace Services
{
    #region using directives

    using Contracts;
    using System;
    using System.ServiceModel;

    #endregion

    public class CalculateImpl : ICalculate
    {
        public void Add(Double num1, Double num2)
        {
            var callBack = OperationContext.Current.GetCallbackChannel<ICalculateCallBack>();
            callBack.DisplayResult((num1 + num2).ToString());
        }

        public void Div(Double num1, Double num2)
        {
            if(num2 == 0)
            {
                var callBack = OperationContext.Current.GetCallbackChannel<ICalculateCallBack>();
                callBack.DisplayResult("Cannot dicide by zero.");
            }
            else
            {
                var callBack = OperationContext.Current.GetCallbackChannel<ICalculateCallBack>();
                callBack.DisplayResult((num1 / num2).ToString());
            }
        }

        public void Mul(Double num1, Double num2)
        {
            var callBack = OperationContext.Current.GetCallbackChannel<ICalculateCallBack>();
            callBack.DisplayResult((num1 * num2).ToString());
        }

        public void Sub(Double num1, Double num2)
        {
            var callBack = OperationContext.Current.GetCallbackChannel<ICalculateCallBack>();
            callBack.DisplayResult((num1 - num2).ToString());
        }
    }
}
