﻿namespace Clients
{
    #region using directives

    using Contracts;
    using System;

    #endregion using directives

    public class CalculateCallBackImpl : ICalculateCallBack
    {
        public void DispalyException(CalculateException exception)
        {
            Console.WriteLine("Exception message:\naction:{0}\nmessage:{1}", exception.Action, exception.Message);
        }

        public void DisplayResult(String result)
        {
            Console.WriteLine("Calculate result:{0}", result);
        }
    }
}
