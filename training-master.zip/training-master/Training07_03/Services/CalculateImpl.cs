﻿namespace Services
{
    #region using directives

    using Contracts;
    using System;
    using System.ServiceModel;

    #endregion

    [ServiceBehavior]
    public class CalculateImpl : ICalculate
    {
        public void Add(Double num1, Double num2)
        {
            var callBack = OperationContext.Current.GetCallbackChannel<ICalculateCallBack>();
            callBack.DisplayResult((num1 + num2).ToString());
        }

        public void Div(Double num1, Double num2)
        {
            try
            {
                if (num2 == 0)
                {
                    throw new Exception("Cannot divide by zero.");
                }
                else
                {
                    var callBack = OperationContext.Current.GetCallbackChannel<ICalculateCallBack>();
                    callBack.DisplayResult((num1 / num2).ToString());
                }
            }
            catch (Exception exception)
            {
                var callBack = OperationContext.Current.GetCallbackChannel<ICalculateCallBack>();
                callBack.DispalyException(new CalculateException("Divide", exception.Message));
            }

        }

        public void Mul(Double num1, Double num2)
        {
            var callBack = OperationContext.Current.GetCallbackChannel<ICalculateCallBack>();
            callBack.DisplayResult((num1 * num2).ToString());
        }

        public void Sub(Double num1, Double num2)
        {
            var callBack = OperationContext.Current.GetCallbackChannel<ICalculateCallBack>();
            callBack.DisplayResult((num1 - num2).ToString());
        }
    }
}
