﻿using System;
using System.Runtime.Serialization;

namespace Contracts
{
    [DataContract(Namespace = "training")]
    public class CalculateException
    {
        [DataMember]
        public String Message { get; set; }

        [DataMember]
        public String Action { get; set; }

        public CalculateException(String action,String message)
        {
            this.Action = action;
            this.Message = message;
        }
    }
}
