﻿window.onload = function () {
    var DTO = {
        Name: "",
        Description: "no description",
        StorageType: "",
        ToString: function () {
            if (this.Description != "") {
                return this.Name + "," + this.Description + "," + this.StorageType + ".";
            }
            else {
                return this.Name + ","+"no description,"+ this.StorageType + ".";
            }
        }
    };
    var saveButton = document.getElementById("saveButton");
    var name = document.getElementById("name");
    var description = document.getElementById("description");
    var storageType = document.getElementById("storageType");
    saveButton.onclick = function () {
        if (name.value == "") {
            alert("Please enter a value.");
        }
        else {
            DTO.Name = name.value;
            DTO.Description = description.value;
            DTO.StorageType = storageType.value;
            alert(DTO.ToString());
        }
    }
}
