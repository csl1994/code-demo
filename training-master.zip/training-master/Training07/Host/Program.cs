﻿namespace Host
{
    #region using directives

    using Contracts;
    using Services;
    using System;
    using System.ServiceModel;

    #endregion using directives
    public class Program
    {
        public static void Main()
        {
            try
            {
                using (var host = new ServiceHost(typeof(CalculateImpl)))
                {
                    host.AddServiceEndpoint(typeof(ICalculate), new NetTcpBinding(), "net.tcp://LoaclHost:8080");
                    host.Opened += delegate
                    {
                        Console.WriteLine("Host start.");
                    };
                    host.Open();
                    Console.ReadLine();
                }
            }
            catch(Exception e)
            {
                Console.WriteLine(e.ToString());
            }
        }
    }
}
