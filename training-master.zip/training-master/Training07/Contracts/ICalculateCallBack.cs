﻿namespace Contracts
{
    #region using directives

    using System;
    using System.ServiceModel;

    #endregion using directives

    [ServiceContract(Namespace = "training")]
    public interface ICalculateCallBack
    {
        [OperationContract(IsOneWay = true)]
        void DisplayResult(String result);
    }
}
