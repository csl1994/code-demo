﻿namespace Contracts
{
    #region using directives

    using System;
    using System.Runtime.Serialization;

    #endregion
    [DataContract]
    public class CalculateException
    {
        [DataMember]
        public String Message { get; set; }

        public CalculateException(String message)
        {
            this.Message = message;
        }
    }
}
