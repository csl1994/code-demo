﻿namespace Clients
{
    #region using directives

    using Contracts;
    using System;

    #endregion using directives

    public class CalculateCallBackImpl : ICalculateCallBack
    {
        public void DisplayResult(String result)
        {
            Console.WriteLine("Calculate result:{0}", result);
        }
    }
}
