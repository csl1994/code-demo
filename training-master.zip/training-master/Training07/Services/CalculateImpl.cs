﻿namespace Services
{
    #region using directives

    using Contracts;
    using System;
    using System.ServiceModel;

    #endregion

    [ServiceBehavior(IncludeExceptionDetailInFaults = true)]
    public class CalculateImpl : ICalculate
    {
        public void Add(Double num1, Double num2)
        {
            var callBack = OperationContext.Current.GetCallbackChannel<ICalculateCallBack>();
            callBack.DisplayResult((num1 + num2).ToString());
        }

        public void Div(Double num1, Double num2)
        {
            var callBack = OperationContext.Current.GetCallbackChannel<ICalculateCallBack>();
            callBack.DisplayResult((num1 / num2).ToString());
        }

        public void Mul(Double num1, Double num2)
        {
            var callBack = OperationContext.Current.GetCallbackChannel<ICalculateCallBack>();
            callBack.DisplayResult((num1 * num2).ToString());
        }

        public void Sub(Double num1, Double num2)
        {
            var callBack = OperationContext.Current.GetCallbackChannel<ICalculateCallBack>();
            callBack.DisplayResult((num1 - num2).ToString());
        }

        public void ThrowException(Double num1, String operation, Double num2)
        {
            switch (operation)
            {
                case "+":
                    Add(num1, num2);
                    break;
                case "-":
                    Sub(num1, num2);
                    break;
                case "*":
                    Mul(num1, num2);
                    break;
                case "/":
                    if (num2 == 0)
                    {
                        throw new FaultException<CalculateException>(new CalculateException("Divide by 0."), 
                            new FaultReason("Parameters passed are not valid"), new FaultCode("Sender or Client"));
                    }
                    Div(num1, num2);
                    break;
                default:
                    throw new FaultException<CalculateException>(new CalculateException("Unknown operation."), 
                        new FaultReason("Operation passed are not valid"), new FaultCode("Sender or Client"));
            }
        }
    }
}
