﻿namespace Training05.Util
{
    #region using directives

    using System;
    using System.IO;
    using System.Text;
    using System.Xml;

    #endregion using directives
    public class XmlUtil
    {
        private static XmlDocument xmlDoc;

        #region Basic Method

        public static void CreateXmlInfo(String destinationXmlFilePath, String directoryPath)
        {
            if (String.IsNullOrWhiteSpace(destinationXmlFilePath) || String.IsNullOrWhiteSpace(directoryPath))
            {
                var exception = new ArgumentException();
                LogUtil.WriteLog(LogLevel.ERROR, exception);
                throw exception;
            }
            xmlDoc = new XmlDocument();
            xmlDoc.CreateXmlDeclaration("1.0", "UTF-8", null);
            var rootNode = xmlDoc.CreateElement("directories");
            var rootPath = xmlDoc.CreateAttribute("path");
            rootPath.Value = directoryPath;
            rootNode.Attributes.Append(rootPath);
            CreateXmlNode(rootNode, directoryPath);
            xmlDoc.AppendChild(rootNode);
            using (var xmlTextWrite = new XmlTextWriter(String.Format("{0}\\result.xml", destinationXmlFilePath), Encoding.UTF8)
            {
                Formatting = Formatting.Indented,
                IndentChar = '\t',
                Indentation = 1
            })
            {
                xmlDoc.Save(xmlTextWrite);
            }
        }

        private static void CreateXmlNode(XmlNode parent, String directoryPath)
        {
            var rootDirectory = new DirectoryInfo(directoryPath);
            LogUtil.WriteLog(LogLevel.INFO, String.Format(":Directory:{0} was found", rootDirectory.FullName));
            foreach (var file in rootDirectory.GetFiles())
            {
                try
                {
                    LogUtil.WriteLog(LogLevel.INFO, String.Format(":File:{0} {1} was found", rootDirectory.FullName, file.Name));
                    var fileNode = xmlDoc.CreateElement("file");
                    var fileName = xmlDoc.CreateAttribute("name");
                    fileName.Value = file.Name;
                    fileNode.Attributes.Append(fileName);
                    var fileFullName = xmlDoc.CreateAttribute("fullname");
                    fileFullName.Value = String.Format("{0}{1}{2}", directoryPath, @"\", file.Name);
                    fileNode.Attributes.Append(fileFullName);
                    var createTime = xmlDoc.CreateAttribute("datecreate");
                    createTime.Value = file.CreationTimeUtc.ToString("yyyy/M/d hh:mm");
                    fileNode.Attributes.Append(createTime);
                    var modifyTime = xmlDoc.CreateAttribute("datemodified");
                    modifyTime.Value = file.LastWriteTimeUtc.ToString("yyyy/M/d hh:mm");
                    fileNode.Attributes.Append(modifyTime);
                    var fileType = xmlDoc.CreateAttribute("type");
                    if (String.IsNullOrWhiteSpace(file.Extension))
                    {
                        fileType.Value = "unknown";
                    }
                    else
                    {
                        fileType.Value = file.Extension;
                    }
                    fileNode.Attributes.Append(fileType);
                    var fileIsReadOnly = xmlDoc.CreateAttribute("isreadonly");
                    fileIsReadOnly.Value = file.IsReadOnly.ToString();
                    fileNode.Attributes.Append(fileIsReadOnly);
                    fileNode.InnerText = MD5Util.GetFileMD5(fileFullName.Value);
                    parent.AppendChild(fileNode);

                }
                catch (Exception exception)
                {
                    LogUtil.WriteLog(LogLevel.WARNING, exception);
                }
            }
            foreach (var directory in rootDirectory.GetDirectories())
            {
                try
                {
                    var directoryNode = xmlDoc.CreateElement("directory");
                    var directoryName = xmlDoc.CreateAttribute("name");
                    directoryName.Value = directory.Name;
                    directoryNode.Attributes.Append(directoryName);
                    var createTime = xmlDoc.CreateAttribute("datecreate");
                    createTime.Value = directory.CreationTimeUtc.ToString("yyyy/M/d hh:mm");
                    directoryNode.Attributes.Append(createTime);
                    var modifyTime = xmlDoc.CreateAttribute("datemodified");
                    modifyTime.Value = directory.LastWriteTimeUtc.ToString("yyyy/M/d hh:mm");
                    directoryNode.Attributes.Append(modifyTime);
                    var directoryType = xmlDoc.CreateAttribute("type");
                    directoryType.Value = "folder";
                    directoryNode.Attributes.Append(directoryType);
                    CreateXmlNode(directoryNode, directory.FullName);
                    parent.AppendChild(directoryNode);
                }
                catch (Exception exception)
                {
                    LogUtil.WriteLog(LogLevel.WARNING, exception);
                }
            }
        }

        public static void RestoreFileInfo(String sourceXmlFilePath, String destinationDirectoryPath)
        {
            if (String.IsNullOrWhiteSpace(sourceXmlFilePath) || String.IsNullOrWhiteSpace(destinationDirectoryPath))
            {
                var exception = new ArgumentException();
                LogUtil.WriteLog(LogLevel.ERROR, exception);
                throw exception;
            }
            xmlDoc = new XmlDocument();
            xmlDoc.Load(sourceXmlFilePath);
            var root = xmlDoc.SelectSingleNode("/");
            var rootNode = root.SelectSingleNode("directories");
            if (!Directory.Exists(destinationDirectoryPath))
            {
                Directory.CreateDirectory(destinationDirectoryPath);
                LogUtil.WriteLog(LogLevel.INFO, String.Format("{0} was built", destinationDirectoryPath));
            }
            else
            {
                LogUtil.WriteLog(LogLevel.INFO, String.Format("{0} already exist", destinationDirectoryPath));
            }
            RestoreFileItem(destinationDirectoryPath, "/directories");
        }

        private static void RestoreFileItem(String destinationDirectoryPath, String elementPath)
        {
            var elementList = xmlDoc.SelectSingleNode(elementPath);
            foreach (XmlNode element in elementList)
            {
                try
                {
                    if (Object.Equals(element.LocalName, "file"))
                    {
                        RestoreFile(destinationDirectoryPath, element);
                    }
                    else if (Object.Equals(element.LocalName, "directory"))
                    {
                        RestoreFileItem(RestoreDirectory(destinationDirectoryPath, element), String.Format("{0}{1}", elementPath, "/directory"));
                    }
                    else
                    {
                        LogUtil.WriteLog(LogLevel.WARNING, String.Format("Meet a unknow node {0}", element.LocalName));
                    }
                }
                catch (Exception exception)
                {
                    LogUtil.WriteLog(LogLevel.WARNING, exception);
                }

            }
        }

        private static String RestoreDirectory(String destinationDirectoryPath, XmlNode element)
        {
            var destinationFullName = new StringBuilder(destinationDirectoryPath);
            destinationFullName.Append("\\");
            destinationFullName.Append(element.Attributes["name"].Value); 
            var directory = new DirectoryInfo(destinationFullName.ToString());
            if (!directory.Exists)
            {
                directory.Create();
                LogUtil.WriteLog(LogLevel.INFO, String.Format("{0} was built", destinationFullName.ToString()));
            }
            else
            {
                LogUtil.WriteLog(LogLevel.WARNING, String.Format("{0} already exist", destinationFullName.ToString()));
            }
            return destinationFullName.ToString();
        }

        private static void RestoreFile(String destinationDirectoryPath, XmlNode element)
        {
            var destinationFullName = new StringBuilder(destinationDirectoryPath);
            destinationFullName.Append("\\");
            destinationFullName.Append(element.Attributes["name"].Value);
            var file = new FileInfo(destinationFullName.ToString());
            if (file.Exists)
            {
                LogUtil.WriteLog(LogLevel.WARNING, String.Format("{0} already exist and would change", file.FullName));
                if (!Object.Equals(element.Attributes["isreadonly"].Value.ToLower(), "false"))
                {
                    file.IsReadOnly = false;
                }
            }
            var sourceFullName = element.Attributes["fullname"].Value;
            if(MD5Util.GetFileMD5(sourceFullName) != element.InnerText)
            {
                LogUtil.WriteLog(LogLevel.INFO, String.Format("{0} was modified", sourceFullName));
            }
            CopyFileUtil.CopyFile(sourceFullName, destinationFullName.ToString());
            if (!Object.Equals(element.Attributes["isreadonly"].Value.ToLower(), "false"))
            {
                file.IsReadOnly = true;
            }
            LogUtil.WriteLog(LogLevel.INFO, String.Format("{0} was built", file.FullName));
        }        

        #endregion Basic Method

    }
}
