﻿namespace Training05.Util
{
    #region using directives

    using System;
    using System.IO;

    #endregion using directives
    public class CopyFileUtil
    {
        public static void CopyFile(String sourceFilePath, String destinationFilePath)
        {
            using (var destinationFileStream = File.Open(destinationFilePath, FileMode.OpenOrCreate, FileAccess.Write))
            {
                const Int32 bufferSize = 4 * 1024 * 1024;
                var fileContentBuffer = new Byte[bufferSize];
                using (var sourceFileStream = File.Open(sourceFilePath, FileMode.Open, FileAccess.Read))
                {
                    Int32 data;
                    do
                    {
                        data = sourceFileStream.Read(fileContentBuffer, 0, fileContentBuffer.Length);
                        destinationFileStream.Write(fileContentBuffer, 0, data);
                    } while (data > 0);
                }
            }
        }
    }
}
