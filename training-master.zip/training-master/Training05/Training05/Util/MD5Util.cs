﻿namespace Training05.Util
{
    #region using directives

    using System;
    using System.IO;
    using System.Security.Cryptography;
    using System.Text;

    #endregion using directives
    public class MD5Util
    {
        public static String GetFileMD5(String fileName)
        {
            if (String.IsNullOrWhiteSpace(fileName))
            {
                var exception = new ArgumentException();
                LogUtil.WriteLog(LogLevel.ERROR, exception);
                throw exception;
            }
            using (var file = new FileStream(fileName, FileMode.Open, FileAccess.Read))
            {
                var md5 = new MD5CryptoServiceProvider();
                var hashValue = md5.ComputeHash(file);
                var result = new StringBuilder();
                foreach (var item in hashValue)
                {
                    result.Append(item.ToString("X2"));
                }
                return result.ToString();
            }
        }
    }
}
