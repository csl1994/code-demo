﻿namespace Training05
{
    #region using directives

    using System;
    using System.IO;
    using Util;

    #endregion using directives
    public class Program
    {
        public static void Main()
        {
            try
            {
                //在黄宁处听过讲解后
                //LogUtil 由原本一个方法 WriteLog(String information)
                //改写成 WriteLog(LogLevel level,String information) 和 WriteLog(LogLevel level, Exception exception)
                //降低了RestoreFileItem的圈复杂度，分解为RestoreFileItem，RestoreDirectory，RestoreFile
                //在XmlUtil中增加了XmlDocument类型的私有字段

                //一个问题，如果把这四个工具类合在一起，从设计上来说会不会更好
                Console.WriteLine("Press enter test program.");
                Console.ReadLine();
                var logPath = "";
                do
                {
                    Console.WriteLine("Input a right log path.");
                    logPath = Console.ReadLine();
                }
                while (!Directory.Exists(logPath));
                LogUtil.LogPath = logPath;
                Console.WriteLine("Create log path completed.Press enter continue test create xml.");
                Console.ReadLine();
                var destinationXmlFilePath = "";
                var directoryPath = "";
                do
                {
                    Console.WriteLine("Input a right destinationXmlFilePath.");
                    destinationXmlFilePath = Console.ReadLine();
                }
                while (!Directory.Exists(destinationXmlFilePath));
                do
                {
                    Console.WriteLine("Input a right directoryPath.");
                    directoryPath = Console.ReadLine();
                }
                while (!Directory.Exists(directoryPath));
                Console.WriteLine("Press enter create xml.");
                Console.ReadLine();
                XmlUtil.CreateXmlInfo(destinationXmlFilePath, directoryPath);
                Console.WriteLine("Creaet xml completed.Press enter continue test create file.");
                Console.ReadLine();
                var sourceXmlFilePath = "";
                var destinationDirectoryPath = "";
                do
                {
                    Console.WriteLine("Input a right sourceXmlFilePath.");
                    sourceXmlFilePath = Console.ReadLine();
                }
                while (!File.Exists(sourceXmlFilePath));
                do
                {
                    Console.WriteLine("Input a right destinationDirectoryPath.");
                    destinationDirectoryPath = Console.ReadLine();
                }
                while (!Directory.Exists(destinationDirectoryPath));
                Console.WriteLine("Press enter create file.");
                Console.ReadLine();
                XmlUtil.RestoreFileInfo(sourceXmlFilePath, destinationDirectoryPath);
                Console.WriteLine("Create file completed.Press enter end.");
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
            finally
            {
                Console.ReadLine();
            }
        }
    }
}
