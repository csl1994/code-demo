public class test{

	/*
	
	 sort this array  {'R','B','B','b','W','W','B','R','B','w','a'}

	 print : a b B B B B R R w W W

	 time complexity O(n)

	 tow show() function is bad
	
	*/

	public static void main(String[] args) {
		test t = new test();

		System.out.println("CountingSort");
		char [] array = {'R','B','B','b','W','W','B','R','B','w'};

        t.CountingSort(array);
		System.out.println("end");
	}

	public void CountingSort(char [] array){

        int min = 0;
        int max = 0;

		for(int i = 0; i < array.length; i ++){
			if(array[min] > array[i]){
				min = i;
			}
			if(array[max] < array[i]){
				max = i;
			}
		}

		int [] arrayT = new int[array[max] - array[min] + 1];
		for(int i = 0; i < arrayT.length; i ++){
			arrayT[i] = 0;
		}

        for(int i = 0; i < array.length; i ++){
        	if(array[i] >= 97){

        	}
        	arrayT[array[i] - array[min]] ++;
        }

        if(array[max] <= 90 || array[min] >= 97){
        	Show_0(arrayT, array[min]);
        } 
        else{
        	Show_1(arrayT, 97 - array[min], 65 - array[min], array[min]);
        }
		
	}

	public void Show_0(int [] arrayT, int k){
		//only big or small
		for(int i = 0; i < arrayT.length; i ++){
			while(arrayT[i] -- > 0){
					System.out.print((char)(i + k) + " ");
			}
		}
	}

	public void Show_1(int [] arrayT, int ii, int jj, int k){

		// i is big, j is small;
		for(int i = ii,j = jj; i < arrayT.length && j < ii; ){
			
			if(j < 0){
				if(arrayT[i] > 0){
					while(arrayT[i] -- > 0){
						System.out.print((char)(i + k) + " ");
					}
				}
				i ++; j ++;
			}
			else{
				if(arrayT[i] == 0 && arrayT[j] != 0){
					while(arrayT[j] -- > 0){
						System.out.print((char)(j + k) + " ");
					}
					i ++; j ++;
				}
				else if(arrayT[i] != 0 && arrayT[j] == 0){
					while(arrayT[i] -- > 0){
						System.out.print((char)(i + k) + " ");
					}
					i ++; j ++;
				}
				else if(arrayT[i] != 0 && arrayT[j] !=0){
					while(arrayT[i] -- > 0){
						System.out.print((char)(i + k) + " ");
					}
					i ++;

					while(arrayT[j] -- > 0){
						System.out.print((char)(j + k) + " ");
					}
					j ++;
					
				}
				else{
					i ++;j ++;
				}
			}
			
		}
	}
}