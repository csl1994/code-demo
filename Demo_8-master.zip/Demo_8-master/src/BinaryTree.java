import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;




public class BinaryTree{
	
	private class BinaryTreeNode{

		private String data;
		private BinaryTreeNode leftChild;
		private BinaryTreeNode rightChild;

		public BinaryTreeNode(){
			this.data = null;
		    leftChild = null;
		    rightChild = null;
		}
		public BinaryTreeNode(String data){
			this.data = data;
		    leftChild = null;
		    rightChild = null;
		}
		public BinaryTreeNode(BinaryTreeNode n){
			this.data = n.data;
		    leftChild = n.leftChild;
		    rightChild = n.rightChild;
		}
		public void setLeftChild(BinaryTreeNode n){
			leftChild = n;
		}
		public void setRightChild(BinaryTreeNode n){
			rightChild = n;
		}
		public void visit(){
			System.out.print(this.data + " ");
		}
		public boolean equals(Object obj){
			if(obj == null){
				return false;
			}else{
				if(obj instanceof BinaryTreeNode){
					BinaryTreeNode n = (BinaryTreeNode) obj;
					return n.data.equals(this.data); 
//�жϽڵ����ʵ�ֲ�����
//					 		&& n.leftChild == this.leftChild) 
//							&& n.rightChild.equals(this.rightChild);
				}
				return false;
			}
		}
    } 


    private String [] array = { "A","B","C","D","E","F"};

    private BinaryTreeNode root = null;

    

    public void createBT(){
    	root = new BinaryTreeNode(array[0]);
    	BinaryTreeNode node_1 = new BinaryTreeNode(array[1]);
    	BinaryTreeNode node_2 = new BinaryTreeNode(array[2]);
    	BinaryTreeNode node_3 = new BinaryTreeNode(array[3]);
    	BinaryTreeNode node_4 = new BinaryTreeNode(array[4]);
    	BinaryTreeNode node_5 = new BinaryTreeNode(array[5]);
    	root.setLeftChild(node_1);
    	root.setRightChild(node_2);
    	node_1.setLeftChild(node_3);
    	node_1.setRightChild(node_4);
    	node_2.setLeftChild(node_5);
    }

    public void levelOrder(){
    	Queue nodeQueue = new LinkedList<BinaryTreeNode>();
    	BinaryTreeNode p = new BinaryTreeNode(root);
    	if(p != null){
    		nodeQueue.offer(p);
    	}
    	while(!nodeQueue.isEmpty()){
    		p = (BinaryTreeNode) nodeQueue.poll();
    		p.visit();
    		if(p.leftChild != null){
    			nodeQueue.offer(p.leftChild);
    		}
    		if(p.rightChild != null){
    			nodeQueue.offer(p.rightChild);
    		}
    	}
    }

    public void preOrder(BinaryTreeNode n){
    	if(n != null){
    		n.visit();
    		preOrder(n.leftChild);
    		preOrder(n.rightChild);
    	}
    }

    public void inOrder(BinaryTreeNode n){
    	if(n != null){
    		inOrder(n.leftChild);
    		n.visit();
    		inOrder(n.rightChild);
    	}
    }

    public void postOrder(BinaryTreeNode n){
    	if(n != null){
    		postOrder(n.leftChild);
    		postOrder(n.rightChild);
    		n.visit();
    	}
    }

    public void PreOrderWithoutRecusion(){
    	Stack nodeStack = new Stack<BinaryTreeNode>();
    	BinaryTreeNode p = new BinaryTreeNode(root);

    	while(!nodeStack.isEmpty() || p != null){
    		if(p != null){
    			p.visit();
    			if(p.leftChild != null){
    				nodeStack.push(p.rightChild);
    			}
    			p = p.leftChild;
    		}
    		else{
    			p = (BinaryTreeNode) nodeStack.pop();
    		}
    	}
    }

    public void InOrderWithoutRecusion(){
    	Stack nodeStack = new Stack<BinaryTreeNode>();
    	BinaryTreeNode p = new BinaryTreeNode(root);
    	
    	while(!nodeStack.isEmpty() || p != null){
    		if(p != null){
    			nodeStack.push(p);
    			p = p.leftChild;
    		}
    		else{
    			p = (BinaryTreeNode) nodeStack.pop();
    			p.visit();
    			p = p.rightChild;
    		}
    	}
    }

    public void PostOrderWithoutRecusion(){
    	Stack nodeStack = new Stack<BinaryTreeNode>();
    	BinaryTreeNode p = new BinaryTreeNode(root);
    	BinaryTreeNode pre = new BinaryTreeNode(root);

    	while(p != null){
    		for(; p.leftChild != null; p = p.leftChild){
    			nodeStack.push(p);
    		}
    		while(p != null  && (p.rightChild == null || p.rightChild.equals(pre))){

    			p.visit();
    			pre = p;
    			if(nodeStack.isEmpty()){
    				return;
    			}
    			p = (BinaryTreeNode) nodeStack.peek();
    			nodeStack.pop();
    		}
    		nodeStack.push(p);
    		p = p.rightChild;
    	}
    }
	public static void main(String [] args){
		BinaryTree bt = new BinaryTree();
		bt.createBT();
		
		System.out.println("");
		System.out.println("������ȱ���");
		bt.levelOrder();
		
		System.out.println("");
		System.out.println("�������_�ݹ�");
		bt.preOrder(bt.root);
		
		System.out.println("");
		System.out.println("�������_�ݹ�");
		bt.inOrder(bt.root);
		
		System.out.println("");
		System.out.println("�������_�ݹ�");
		bt.postOrder(bt.root);
		
		System.out.println("");
		System.out.println("�������_�ǵݹ�");
		bt.PreOrderWithoutRecusion();
		
		System.out.println("");
		System.out.println("�������_�ǵݹ�");
		bt.InOrderWithoutRecusion();
	
		System.out.println("");
		System.out.println("�������_�ǵݹ�");
		bt.PostOrderWithoutRecusion();
		
		System.out.println("");
		System.out.println("end");
	}
}

