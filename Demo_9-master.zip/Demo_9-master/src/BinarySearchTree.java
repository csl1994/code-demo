
public class BinarySearchTree {

	private BinarySearchTreeNode root = new BinarySearchTreeNode();
	
	private class BinarySearchTreeNode{

		private int data;
		private BinarySearchTreeNode leftChild;
		private BinarySearchTreeNode rightChild;

		public BinarySearchTreeNode(){
			this.data = -1;
		    this.leftChild = null;
		    this.rightChild = null;
		}
		public BinarySearchTreeNode(int data){
			this.data = data;
		    this.leftChild = null;
		    this.rightChild = null;
		}
		public BinarySearchTreeNode(BinarySearchTreeNode n){
			this.data = n.data;
		    this.leftChild = n.leftChild;
		    this.rightChild = n.rightChild;
		}
		public void setLeftChild(BinarySearchTreeNode n){
			this.leftChild = n;
		}
		public void setRightChild(BinarySearchTreeNode n){
			this.rightChild = n;
		}
		public void visit(){
			System.out.print(this.data + " ");
		}
		public boolean equals(Object obj){
			if(obj == null){
				return false;
			}else{
				if(obj instanceof BinarySearchTreeNode){
					BinarySearchTreeNode n = (BinarySearchTreeNode) obj;
					return n.data == this.data; 
//�жϽڵ����ʵ�ֲ�����
//					 		&& n.leftChild == this.leftChild) 
//							&& n.rightChild.equals(this.rightChild);
				}
				return false;
			}
		}
		public int getData() {
			return data;
		}
		public void setData(int data) {
			this.data = data;
		}
		public BinarySearchTreeNode getLeftChild() {
			return leftChild;
		}
		public BinarySearchTreeNode getRightChild() {
			return rightChild;
		}
		
     } 
	
	//����
	public void preOrder(BinarySearchTreeNode n){
	    	if(n != null){
	    		n.visit();
	    		preOrder(n.leftChild);
	    		preOrder(n.rightChild);
	    	}
	}
	 
	//����
    public BinarySearchTreeNode search(int key){
    	
    	BinarySearchTreeNode current = root;
    	
    	while(current.getData() != key){
    		if(current.getData() > key){
        		current = current.leftChild;
        	}
        	else if(current.getData() < key){
        		current = current.rightChild;
        	}
    	}
    	
    	if(current == null){
    		return null;
    	}
    	return current;
    }
    
    //���Ҹ��ڵ�
    public BinarySearchTreeNode findParent(int key){
    	BinarySearchTreeNode current = root;
    	BinarySearchTreeNode parent = null;
    	
    	while(current.getData() != key){
    		parent = current;
    		
    		if(current.getData() > key){
        		current = current.leftChild;
        	}
        	else if(current.getData() < key){
        		current = current.rightChild;
        	}
    	}
    	
    	if(current == null){
    		return null;
    	}
    	return parent;
    }
    
    //����
    public void insertNode(int data){
    	
    	BinarySearchTreeNode p = root;
    	BinarySearchTreeNode prev = null;
    	
    	while(p != null){
    		prev = p;
    		if(p.getData() < data){
    			p = p.rightChild;
    		}
    		else{
    			p = p.leftChild;
    		}
    	}
    	if(root == null){
    		root = new BinarySearchTreeNode(data);
    	}
    	else if(prev.getData() < data){
    		prev.rightChild = new BinarySearchTreeNode(data);
    	}
    	else{
    		prev.leftChild = new BinarySearchTreeNode(data);
    	}
    	
    	
    }
    
    //�ϲ�ɾ��
    public void deleteByMerging(int data){
    	
    	BinarySearchTreeNode current = search(data);
    	BinarySearchTreeNode parent = findParent(data);
    	
    	if (current == root) { 
            root = null;  
            return ;
        } 
    	
    	if(current != null){
    		if(current.rightChild == null){
    			if(current.equals(parent.leftChild)){
    				parent.leftChild = current.leftChild;
    			}
    			else if(current.equals(parent.rightChild)){
    				parent.rightChild = current.leftChild;
    			}
    		}
    		else if(current.leftChild == null){
    			if(current.equals(parent.leftChild)){
    				parent.leftChild = current.rightChild;
    			}
    			else if(current.equals(parent.rightChild)){
    				parent.rightChild = current.rightChild;
    			}
    		}
    		else{
    			BinarySearchTreeNode tmp = current.leftChild;
    			while(tmp.rightChild != null){
    				tmp = tmp.rightChild;
    			}
    			tmp.rightChild = current.rightChild;
    			tmp = current;
    			
    			if(current.equals(parent.leftChild)){
    				parent.leftChild = current.leftChild;
    			}
    			else if(current.equals(parent.rightChild)){
    				parent.rightChild = current.leftChild;
    			}
    		}
    	}
    	
    }
    
    //����ɾ��
    public void deleteByCopying(int data){
    	
    	BinarySearchTreeNode current = search(data);
    	BinarySearchTreeNode parent = findParent(data);
    	
    	if (current == root) { 
            root = null;  
            return ;
        } 
    	
    	if(current != null){
    		if(current.rightChild == null){
    			if(current.equals(parent.leftChild)){
    				parent.leftChild = current.leftChild;
    			}
    			else if(current.equals(parent.rightChild)){
    				parent.rightChild = current.leftChild;
    			}
    		}
    		else if(current.leftChild == null){
    			if(current.equals(parent.leftChild)){
    				parent.leftChild = current.rightChild;
    			}
    			else if(current.equals(parent.rightChild)){
    				parent.rightChild = current.rightChild;
    			}
    		}
    		else{
    			BinarySearchTreeNode tmp = current.rightChild;
    			//��������Сֵ
    			while(tmp.leftChild != null){
    				tmp = tmp.leftChild;
    			}
    			int t = tmp.getData();
    			deleteByCopying(tmp.getData());
    			current.setData(t);
    		}
    	}
    	
    }
    
    
    public BinarySearchTree() {
		this.root = null;
	}
    
    
	public BinarySearchTree(BinarySearchTreeNode root) {
		this.root = root;
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//�����ؼ�ֵ��ͬ�Ľڵ�ʱ������
		int array [] = {20,3,5,76,34,1,67,2,80,33};
		BinarySearchTree bst = new BinarySearchTree();
		
		for(int i = 0; i < array.length; i ++){
			bst.insertNode(array[i]);
		}
		bst.preOrder(bst.root);
		System.out.println("");
		
		
		bst.deleteByMerging(array[1]);
		bst.preOrder(bst.root);
		System.out.println("");
		
		bst.deleteByCopying(array[4]);
		bst.preOrder(bst.root);
		System.out.println("");
		
		
		System.out.println("end");
	}
	
	

}
