
public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] array1 = {3,5,6,1,7,9,5,1,9,0,7,4}; 
		show(array1);
		System.out.println("��Ԫѡ������");
		SelectSort(array1);
		
		int [] array2 = {3,5,6,1,7,9,5,1,9,0,7,4};
		show(array2);
		System.out.println("������");
		HeapSort(array2);
	}
	
	//ѡ������,ͬʱɸѡ��min && max
	public static void SelectSort(int [] array){
		int min = 0;
		int max = 0;
		int tem1 = 0;
		int tem2 = 0;
		int i = 0;
		int j = 0;
		
		for(i = 0; i < array.length / 2; i ++){
			min = max = i;
			for(j = i + 1; j < array.length - i; j ++){
				if(array[min] > array[j]){
					min = j;
				}
				if(array[max] < array[j]){
					max = j;
				}
			}
			if(min == j-1 && max == i){
				//��ֹ�ظ�����
				tem1 = array[min];
				array[min] = array[i];
				array[i] = tem1; 
				show(array);
			}
			else{
				tem1 = array[min];
				array[min] = array[i];
				array[i] = tem1; 
				tem2 = array[max];
				array[max] = array[j - 1];
				array[j - 1] = tem2;
				show(array);
			}
		}
		
	}
	
	//������,ע��leftChild
	public static void HeapAdjust(int [] array, int root, int top){
		int temp = array[root];
		int leftChild = 2 * (root - top) + top + 1;
		int rightChid = leftChild + 1;
		int compareChild = 0;
		while(leftChild < array.length){
			if(rightChid < array.length && array[rightChid] < array[leftChild]){
				compareChild = rightChid;
			}else{
				compareChild = leftChild;
			}
			
			if(array[root] > array[compareChild]){
				array[root] = array[compareChild];
				root = compareChild;
				leftChild = 2 * compareChild + 1;
			}else{
				break;
			}
			array[root] = temp;
		}
	}
	public static void BuildHeap(int [] array,int top){
		//�ı�������±�ʹ�öѶ��ı䣬�ٶ��µĶѽ�����飬ע��leftChild
		for(int i = (array.length + top - 1) / 2; i >= top; i --){
			HeapAdjust(array, i, top);
		}
	}
	public static void HeapSort(int [] array){
		for(int i = 0; i < array.length; i ++){
			BuildHeap(array, i);
			show(array);
		}
	}
	
	//���
	public static void show(int [] array){
		
		for(int i = 0; i < array.length; i ++){
			System.out.print(array[i] + " ");
		}
		System.out.println("");
	}
}