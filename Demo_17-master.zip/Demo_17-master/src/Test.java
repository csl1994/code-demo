public class Test{

	public static void main(String[] args) {
		Test t = new Test();
		int i = t.f(6);
		System.out.println(i);
	}

	public int f(int i){

		if(i == 1 || i == 2){
			return 1;
		}
		else{
			return f(i - 1) + f(i - 2);
		}
	}
}
















