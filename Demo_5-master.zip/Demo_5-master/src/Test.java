import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Stack;
import java.util.Vector;


public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("һ");
		//ʹ��ArrayList
		List list1 = new ArrayList<Integer>();//int Ϊ�������ͣ���integerΪ�����ڽ��з��Ͷ���ʱ����ʹ��int��
		list1.add(0);
		list1.add(1);
		list1.add(2);
		
		for(Iterator i = list1.iterator();i.hasNext(); ){
			Integer ii = (Integer) i.next();
			System.out.print(ii + "  ");
		}
		System.out.println("");
		
		System.out.println("��");
		//ʹ��Vector
		List list2 = new Vector<Integer>();
		list2.add(0);
		list2.add(1);
		list2.add(2);
		list2.set(0, 3);
		
		for(Iterator i = list2.iterator();i.hasNext(); ){
			Integer ii = (Integer) i.next();
			System.out.print(ii + "  ");
		}
		System.out.println("");
		
		System.out.println("��");
		//ʹ��LinkedList
		LinkedList list3 = new LinkedList<String>();
		list3.add("a");
		list3.add("b");
		list3.add("c");
		list3.remove(0);
		list3.addFirst("d");
		list3.addLast("e");
		
		for(Iterator i = list3.iterator();i.hasNext(); ){
			String str = (String) i.next();
			System.out.print(str + "  ");
		}
		System.out.println("");
		
		System.out.println("��");
		//ʹ��Stack
		Stack list4 = new Stack<String>();
		list4.push("a");
		list4.push("b");
		list4.push("c");
		
		for(Iterator i = list4.iterator();i.hasNext(); ){
			String str = (String) i.next();
			System.out.print(str + "  ");
		}
		System.out.println("");
		
		System.out.println("��");
		//ʹ��Queue
		Queue list5 = new LinkedList<String>();
		list5.offer("a");
		list5.offer("b");
		list5.offer("c");
		
		for(Iterator i = list5.iterator();i.hasNext(); ){
			String str = (String) i.next();
			System.out.print(str + "  ");
		}
		System.out.println("");
	}

}
