public class test{

	public static void main(String[] args) {
		test t = new test();

		System.out.println("BinarySearch");
        int [] array_1 = {10, 13, 17, 23, 38, 46, 54, 65, 82, 89, 92};
        t.BinarySearch(array_1, 23);
		System.out.println("end");
	}

	public void BinarySearch(int [] array, int key){
		//array is mid to max
		int left = 1;
		int right = array.length;
		
		while(left < right){

			int mid = (left + right) >> 1;
			if(array[mid] > key){
				right = mid - 1;
			}
			else if(array[mid] < key){
				left = mid + 1;
			}
			else{
				System.out.println("array[" + mid + "] = " + key);
				return;
			}
		}

		System.out.println("not exist the " + key);
	}
}